module.exports = function(deployer) {
  deployer.deploy(ConvertLib);
  deployer.autolink();
  deployer.deploy(MetaCoin);
 deployer.deploy(SecurityChain);
 deployer.deploy(settlement);
 deployer.deploy(Signoff);
 deployer.deploy(TermChain);
};
