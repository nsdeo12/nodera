module.exports = {
  deploy: [
    "customerData",
    "SecurityChain",
    "Signoff",
    "TermChain",
"settlement"
  ],
  rpc: {
    host: "localhost",
    port: 7890
  }
};
