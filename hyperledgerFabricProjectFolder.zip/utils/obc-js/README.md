# ibm-blockchain-js

[https://github.com/IBM-Blockchain/ibm-blockchain-js](https://github.com/IBM-Blockchain/ibm-blockchain-js)
