var mysql = require('mysql');
var shareddb  = mysql.createPool({
  connectionLimit : 1500,
  host            : 'localhost',
  user            : 'root',
  password        : 'root',
  database        : 'shareddb'
});



var beneficiarybank  = mysql.createPool({
  connectionLimit : 1500,
  host            : 'localhost',
  user            : 'root',
  password        : 'root',
  database        : 'beneficiarybank'
});



var applicantbank  = mysql.createPool({
  connectionLimit : 1500,
  host            : 'localhost',
  user            : 'root',
  password        : 'root',
  database        : 'applicantbank'
});
