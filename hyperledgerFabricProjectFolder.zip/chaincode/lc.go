package main

import (
	"errors"
	"fmt"
	//	"strconv"
	"encoding/json"

	"github.com/hyperledger/fabric/core/chaincode/shim"
)

var LCID = "LCID"
var BGID = "BGID"

var logger = shim.NewLogger("mylogger")

type SimpleChaincode struct {
}

type LetterOfCredit struct {
	LcId                            string                       `json:"lcId"`
	LcReqId                         string                       `json:"lcReqId"`
	ApplicantCustomer               string                       `json:"applicantCustomer"`
	ApplicantAddress                string                       `json:"applicantAddress"`
	LcExpiryDate                    string                       `json:"lcExpiryDate"`
	ModeOfShipment                  string                       `json:"modeOfShipment"`
	BeneficiaryId                   string                       `json:"beneficiaryId"`
	BeneficiaryAddress              string                       `json:"beneficiaryAddress"`
	LcType                          string                       `json:"lcType"`
	LcCurrency                      string                       `json:"lcCurrency"`
	LcAmount                        int                          `json:"lcAmount"`
	LcAmountTemp                    int                          `json:"lcAmountTemp"`
	LcIssueDate                     string                       `json:"lcIssueDate"`
	LcExpiryPlace                   string                       `json:"lcExpiryPlace"`
	LatestShipmentDate              string                       `json:"latestShipmentDate"`
	LiabilityReversalDate           string                       `json:"liabilityReversalDate"`
	AdvisingBankID                  string                       `json:"advisingBankID"`
	ApplicantBank                   string                       `json:"applicantBank"`
	ApplicantBankAddress            string                       `json:"applicantBankAddress"`
	AdvisingBankAddress             string                       `json:"advisingBankAddress"`
	FormofDocumentaryCredit         string                       `json:"formofDocumentaryCredit"`
	DocumentaryCreditNumber         string                       `json:"documentaryCreditNumber"`
	AvailableWithBy                 string                       `json:"availableWithBy"`
	ForTransportationTo             string                       `json:"forTransportationTo"`
	DescriptionOfGoodsAndOrServices string                       `json:"descriptionOfGoodsAndOrServices"`
	AdditionalConditions            string                       `json:"additionalConditions"`
	PeriodForPresentation           string                       `json:"periodForPresentation"`
	AdvisingThroughBank             string                       `json:"advisingThroughBank"`
	Transshipment                   string                       `json:"transshipment"`
	PortofLoading                   string                       `json:"portofLoading"`
	MaximumCreditAmount             string                       `json:"maximumCreditAmount"`
	DraftsAt                        string                       `json:"draftsAt"`
	PartialShipments                string                       `json:"partialShipments"`
	SenderToReceiverInformation     string                       `json:"senderToReceiverInformation"`
	Charges                         string                       `json:"charges"`
	ConfirmationInstructions        string                       `json:"confirmationInstructions"`
	SequenceOfTotal                 string                       `json:"sequenceOfTotal"`
	DocumentsRequired               string                       `json:"documentsRequired"`
	IbanNumber                      string                       `json:"ibanNumber"`
	IncoTerms                       string                       `json:"incoTerms"`
	DraftsAtSight                   string                       `json:"draftsAtSight"`
	DraftsAtUsance                  string                       `json:"draftsAtUsance"`
	ShipmentPeriodSight             int                          `json:"shipmentPeriodSight"`
	ShipmentPeriodUsance            int                          `json:"shipmentPeriodUsance"`
	PercentageSight                 int                          `json:"percentageSight"`
	PercentageUsance                int                          `json:"percentageUsance"`
	LcAmountSight                   int                          `json:"lcAmountSight"`
	LcAmountUsance                  int                          `json:"lcAmountUsance"`
	Status                          string                       `json:"status"`
	AmendArray                      []AmendLetterOfCreditDetails `json:"amendArray"`
	LcNumberOfAmendments            int                          `json:"LcNumberOfAmendments"`
	Bill                            []Bills
	AdvisingBankRef                 string `json:"lcAmendAdvisingBankRef"`
	AmendmentDetails                string `json:"lcAmendmentDetails"`
}
type Bills struct {
	BillNo           string `json:"billNo"`
	BillAmount       int    `json:"billAmount"`
	CurrencyType     string `json:"currencyType"`
	BillDate         string `json:"billDate"`
	LcOutstandingAmt int    `json:"lcOutstandingAmt"`
}

type AmendLetterOfCreditDetails struct {
	LcId                 string `json:"lcId"`
	LcAmendReqId         string `json:"lcAmendReqId"`
	LcAmount             int    `json:"lcAmendAmount"`
	AdvisingBankRef      string `json:"lcAmendAdvisingBankRef"`
	ModeOfShipment       string `json:"amendModeOfShipment"`
	LcExpiryDate         string `json:"lcAmendExpiryDate"`
	AmendmentDetails     string `json:"lcAmendmentDetails"`
	LcExpiryPlace        string `json:"lcAmendExpiryPlace"`
	Status               string `json:"status"`
	LcNumberOfAmendments int    `json:"LcNumberOfAmendments"`
}

type BankGuarantee struct {
	BgId                        string                      `json:"bgId"`
	BgReqId                     string                      `json:"bgReqID"`
	GuaranteeReference          string                      `json:"guaranteeReference"`
	CustomerReference           string                      `json:"customerReference"`
	ApplicantCustomer           string                      `json:"applicantCustomer"`
	ApplicantCustomeraddress    string                      `json:"applicantCustomerAddress"`
	Currency                    string                      `json:"currency"`
	PrincipalAmount             int                         `json:"principalAmount"`
	BeneficiaryBankaddress      string                      `json:"beneficiaryBankAddress"`
	BeneficiaryBank             string                      `json:"beneficiaryBank"`
	ApplicantBank               string                      `json:"applicantBank"`
	ApplicantBankAddress        string                      `json:"applicantBankAddress"`
	DealDate                    string                      `json:"dealDate"`
	Valuedate                   string                      `json:"valueDate"`
	ExpiryDate                  string                      `json:"expiryDate"`
	MaturityDate                string                      `json:"maturityDate"`
	Beneficiary                 string                      `json:"beneficiary"`
	BeneficiaryAddress          string                      `json:"beneficiaryAddress"`
	TermsAndConditions          string                      `json:"termsAndConditions"`
	Ibannumber                  string                      `json:"ibanNumber"`
	FurtherIdentification       string                      `json:"furtherIdentification"`
	DetailsOfGuarantee1         string                      `json:"detailsOfGuarantee1"`
	ApplicableRule              string                      `json:"applicableRule"`
	SenderToReceiverInformation string                      `json:"senderToReceiverInformation"`
	Narrative                   string                      `json:"narrative"`
	Status                      string                      `json:"status"`
	BgNumberOfAmendments        int                         `json:"bgNumberOfAmendments"`
	BGAmendArray                []AmendBankGuaranteeDetails `json:"bgAmendArray"`
}

type AmendBankGuaranteeDetails struct {
	BgId                 string `json:"bgId"`
	BgAmendReqId         string `json:"bgAmendReqId"`
	PrincipalAmount      int    `json:"principalAmount"`
	TermsAndConditions   string `json:"termsAndConditions"`
	ExpiryDate           string `json:"expiryDate"`
	Status               string `json:"status"`
	BgNumberOfAmendments int    `json:"bgNumberOfAmendments"`
}

func (t *SimpleChaincode) Init(stub shim.ChaincodeStubInterface, function string, args []string) ([]byte, error) {

	var err error

	var empty []string
	jsonAsBytes, _ := json.Marshal(empty)
	err = stub.PutState(LCID, jsonAsBytes)
	err = stub.PutState(BGID, jsonAsBytes)

	if err != nil {
		return nil, err
	}

	return nil, nil

}

func (t *SimpleChaincode) Invoke(stub shim.ChaincodeStubInterface, function string, args []string) ([]byte, error) {

	if function == "OpenLetterOfCredit" {
		// creates an entity from its state
		return t.OpenLetterOfCredit(stub, args)
	}
	if function == "OpenBankGuarantee" {
		// creates an entity from its state
		return t.OpenBankGuarantee(stub, args)
	}
	if function == "UpdateStatus" {
		// updates an entity from its state
		return t.UpdateStatus(stub, args)
	}

	if function == "BGApprove" {
		// updates an entity from its state
		return t.BGApprove(stub, args)
	}
	if function == "VerifyBill" {
		return t.VerifyBill(stub, args)
		//updates the status as Bills uploaded
	}
	if function == "LodgeBill" {
		// creates an entity from its state
		return t.LodgeBill(stub, args)
	}

	if function == "AmendLetterOfCredit" {
		// updates a record based on lcId
		return t.AmendLetterOfCredit(stub, args)
	}
	if function == "AmendBankGuarantee" {
		// updates a record based on lcId
		return t.AmendBankGuarantee(stub, args)
	}

	return nil, nil
}

func (t *SimpleChaincode) Query(stub shim.ChaincodeStubInterface, function string, args []string) ([]byte, error) {
	if function == "GetLcById" {
		// creates an entity from its state
		return t.GetLcById(stub, args)
	}
	if function == "GetAllLC" {
		// creates an entity from its state
		return t.GetAllLC(stub, args)
	}
	if function == "GetCustomerBasedRecords" {
		// creates an entity from its state
		return t.GetCustomerBasedRecords(stub, args)
	}
	if function == "GetCustomerBasedBgRecords" {
		// creates an entity from its state
		return t.GetCustomerBasedBgRecords(stub, args)
	}
	if function == "GetBgById" {
		// creates an entity from its state
		return t.GetBgById(stub, args)
	}
	if function == "GetAllBG" {
		// creates an entity from its state
		return t.GetAllBG(stub, args)
	}
	return nil, nil
}

//Modification starts

func (t *SimpleChaincode) GetCustomerBasedRecords(stub shim.ChaincodeStubInterface, args []string) ([]byte, error) {
	logger.Debug("Entering GetCustomerBasedRecords")

	var jsonRespAll string
	var data []byte
	var IDs []string
	var LcArrayAsBytes []byte
	var customerName = args[0]

	IDAsBytes, err := stub.GetState(LCID)
	if err != nil {
		//return fail, errors.New("Failed to get math index")
	}
	json.Unmarshal(IDAsBytes, &IDs)
	fmt.Println("IDAsBytes :", IDs)

	for i := range IDs {
		fmt.Println("IDs :", IDs[i])
		var ID = IDs[i]
		LcArrayAsBytes, err = stub.GetState(ID)
		if err != nil {
			fmt.Println("error in fetching record")
			//return fail, errors.New("Failed to get ")
		}

		res := LetterOfCredit{}
		json.Unmarshal(LcArrayAsBytes, &res)
		fmt.Println("customerName   " + customerName)
		fmt.Println("res   ", res)
		if (res.ApplicantCustomer == customerName) || (res.BeneficiaryId == customerName) {
			//fmt.Println("res data:", res)
			s1, _ := json.Marshal(res)

			jsonRespAll = jsonRespAll + string(s1)
			fmt.Println("jsonRespAll   " + jsonRespAll)

			data = []byte(jsonRespAll)
		}
	}
	fmt.Println("outside for loop data   ", data)
	return data, nil

}

//modification ends

//bg customer records

func (t *SimpleChaincode) GetCustomerBasedBgRecords(stub shim.ChaincodeStubInterface, args []string) ([]byte, error) {
	logger.Debug("Entering GetCustomerBasedBgRecords")

	var bgjsonRespAll string
	var bgdata []byte
	var BGIDs []string
	var BgArrayAsBytes []byte
	var customerName = args[0]

	BGIDAsBytes, err := stub.GetState(BGID)
	if err != nil {
		//return fail, errors.New("Failed to get math index")
	}
	json.Unmarshal(BGIDAsBytes, &BGIDs)
	fmt.Println("BGIDAsBytes :", BGIDs)

	for i := range BGIDs {
		fmt.Println("BGIDs :", BGIDs[i])
		var ID = BGIDs[i]
		BgArrayAsBytes, err = stub.GetState(ID)
		if err != nil {
			fmt.Println("error in fetching record")
			//return fail, errors.New("Failed to get ")
		}

		res := BankGuarantee{}
		json.Unmarshal(BgArrayAsBytes, &res)
		fmt.Println("customerName   " + customerName)
		fmt.Println("res   ", res)
		if (res.ApplicantCustomer == customerName) || (res.Beneficiary == customerName) {
			//fmt.Println("res data:", res)
			s1, _ := json.Marshal(res)

			bgjsonRespAll = bgjsonRespAll + string(s1)
			fmt.Println("bgjsonRespAll   " + bgjsonRespAll)

			bgdata = []byte(bgjsonRespAll)
		}
	}
	fmt.Println("outside for loop data   ", bgdata)
	logger.Debug("Exiting GetCustomerBasedBgRecords")
	return bgdata, nil

}

//end

func (t *SimpleChaincode) OpenLetterOfCredit(stub shim.ChaincodeStubInterface, args []string) ([]byte, error) {
	logger.Debug("Entering OpenLetterOfCredit")

	if len(args) < 2 {
		logger.Error("Invalid number of args")
		return nil, errors.New("Expected atleast two arguments for letter of credit creation")
	}

	var lcId = args[0]
	var lcInput = args[1]

	//storing the Lc IDs

	LCIDAsBytes, err := stub.GetState(LCID)
	if err != nil {
		return nil, errors.New("Failed to get Student IDs")
	}

	var LCIDs []string
	json.Unmarshal(LCIDAsBytes, &LCIDs)
	fmt.Println("LCIDs  ", LCIDs)

	//store and append the index to LCIDs

	LCIDs = append(LCIDs, args[0])
	fmt.Println("LCIDs array: ", LCIDs)

	LCIdArrayAsBytes, _ := json.Marshal(LCIDs)
	err = stub.PutState(LCID, LCIdArrayAsBytes)

	//END

	locObj := LetterOfCredit{}
	err = json.Unmarshal([]byte(lcInput), &locObj)
	fmt.Println("locObj object====>  ", locObj)

	s1, _ := json.Marshal(locObj)

	err = stub.PutState(lcId, []byte(s1))
	if err != nil {
		logger.Error("Could not save letter of credit to ledger", err)
		return nil, err
	}

	var customEvent = "{eventType: 'Letter of credit', description:" + lcId + "' Successfully created'}"
	err = stub.SetEvent("evtSender", []byte(customEvent))
	if err != nil {
		return nil, err
	}
	logger.Info("Successfully requested a Letter of credit")

	return nil, nil

}
func (t *SimpleChaincode) OpenBankGuarantee(stub shim.ChaincodeStubInterface, args []string) ([]byte, error) {
	logger.Debug("Entering Bank Guarantee")

	if len(args) < 2 {
		logger.Error("Invalid number of args")
		return nil, errors.New("Expected atleast two arguments for letter of credit creation")
	}

	var bgId = args[0]
	var bgInput = args[1]

	logger.Info("arguements in chaincode=================>>>", bgId, bgInput)

	//storing the Lc IDs

	BGIDAsBytes, err := stub.GetState(BGID)
	if err != nil {
		return nil, errors.New("Failed to get BG IDs")
	}

	var BGIDs []string
	json.Unmarshal(BGIDAsBytes, &BGIDs)
	fmt.Println("BGIDs  ", BGIDs)

	//store and append the index to BGIDs

	BGIDs = append(BGIDs, args[0])
	fmt.Println("BGIDs array: ", BGIDs)

	BGIdArrayAsBytes, _ := json.Marshal(BGIDs)
	err = stub.PutState(BGID, BGIdArrayAsBytes)

	//END

	bogObj := BankGuarantee{}
	err = json.Unmarshal([]byte(bgInput), &bogObj)
	fmt.Println("bogObj object====>  ", bogObj)

	s1, _ := json.Marshal(bogObj)

	err = stub.PutState(bgId, []byte(s1))
	if err != nil {
		logger.Error("Could not save bank guarantee to ledger", err)
		return nil, err
	}

	var customEvent = "{eventType: 'Bank Guarantee', description:" + bgId + "' Successfully created'}"
	err = stub.SetEvent("evtSender", []byte(customEvent))
	if err != nil {
		return nil, err
	}
	logger.Info("Successfully requested a Bank Gauarantee")

	return nil, nil

}

func (t *SimpleChaincode) GetLcById(stub shim.ChaincodeStubInterface, args []string) ([]byte, error) {
	logger.Debug("Entering GetLcById")

	if len(args) < 1 {
		logger.Error("Invalid number of arguments")
		return nil, errors.New("Missing LC ID")
	}

	var lcId = args[0]
	bytes, err := stub.GetState(lcId)
	if err != nil {
		logger.Error("Could not fetch letter of credit with id "+lcId+" from ledger", err)
		return nil, err
	}
	return bytes, nil
}

func (t *SimpleChaincode) GetBgById(stub shim.ChaincodeStubInterface, args []string) ([]byte, error) {
	logger.Debug("Entering GetBgById")

	if len(args) < 1 {
		logger.Error("Invalid number of arguments")
		return nil, errors.New("Missing BG ID")
	}

	var bgId = args[0]
	bytes, err := stub.GetState(bgId)
	if err != nil {
		logger.Error("Could not fetch letter of credit with id "+bgId+" from ledger", err)
		return nil, err
	}
	return bytes, nil
}

func (t *SimpleChaincode) GetAllLC(stub shim.ChaincodeStubInterface, args []string) ([]byte, error) {
	logger.Debug("Entering GetAllLC")

	var jsonRespAll string
	var data []byte
	var IDs []string
	var LcArrayAsBytes []byte

	IDAsBytes, err := stub.GetState(LCID)
	if err != nil {
		//return fail, errors.New("Failed to get math index")
	}
	json.Unmarshal(IDAsBytes, &IDs)
	fmt.Println("IDAsBytes :", IDs)

	for i := range IDs {
		fmt.Println("IDs :", IDs[i])
		var ID = IDs[i]
		LcArrayAsBytes, err = stub.GetState(ID)
		if err != nil {
			fmt.Println("error in fetching record")
			//return fail, errors.New("Failed to get ")
		}

		res := LetterOfCredit{}
		json.Unmarshal(LcArrayAsBytes, &res)
		//fmt.Println("res data:", res)
		s1, _ := json.Marshal(res)

		jsonRespAll = jsonRespAll + string(s1)
		fmt.Println("jsonRespAll   " + jsonRespAll)

		data = []byte(jsonRespAll)

	}
	return data, nil

}

func (t *SimpleChaincode) GetAllBG(stub shim.ChaincodeStubInterface, args []string) ([]byte, error) {
	logger.Debug("Entering GetAllBG")

	var bgjsonRespAll string
	var bgdata []byte
	var bgIDs []string
	var BgArrayAsBytes []byte

	BGIDAsBytes, err := stub.GetState(BGID)
	if err != nil {
		//return fail, errors.New("Failed to get math index")
	}
	json.Unmarshal(BGIDAsBytes, &bgIDs)
	fmt.Println("BGIDAsBytes :", bgIDs)

	for i := range bgIDs {
		fmt.Println("bgIDs :", bgIDs[i])
		var ID = bgIDs[i]
		BgArrayAsBytes, err = stub.GetState(ID)
		if err != nil {
			fmt.Println("error in fetching record")
			//return fail, errors.New("Failed to get ")
		}

		res := BankGuarantee{}
		json.Unmarshal(BgArrayAsBytes, &res)
		//fmt.Println("res data:", res)
		s1, _ := json.Marshal(res)

		bgjsonRespAll = bgjsonRespAll + string(s1)
		fmt.Println("bgjsonRespAll   " + bgjsonRespAll)

		bgdata = []byte(bgjsonRespAll)

	}
	return bgdata, nil

}

func (t *SimpleChaincode) UpdateStatus(stub shim.ChaincodeStubInterface, args []string) ([]byte, error) {
	logger.Debug("Entering UpdateStatus")
	if len(args) < 2 {
		logger.Error("Invalid number of arguments")
		return nil, errors.New("Missing LC ID")
	}

	var lcid = args[0]
	var status = args[1]
	bytes, err := stub.GetState(lcid)
	if err != nil {
		logger.Error("Could not fetch letter of credit with id "+lcid+" from ledger", err)
		return nil, err
	}
	loc := LetterOfCredit{}
	json.Unmarshal(bytes, &loc)
	fmt.Println("loc data:", loc)
	loc.Status = status
	fmt.Println("loc data after status change:", loc)
	s2, _ := json.Marshal(loc)

	err = stub.PutState(lcid, s2)
	if err != nil {
		logger.Error("Could not save letter of credit to ledger", err)
		return nil, err
	}

	return nil, nil
}

func (t *SimpleChaincode) BGApprove(stub shim.ChaincodeStubInterface, args []string) ([]byte, error) {
	logger.Debug("Entering BG Approval Status")
	if len(args) < 2 {
		logger.Error("Invalid number of arguments")
		return nil, errors.New("Missing BG ID")
	}

	var bgId = args[0]
	var status = args[1]
	bytes, err := stub.GetState(bgId)
	if err != nil {
		logger.Error("Could not fetch BG Approve with id "+bgId+" from ledger", err)
		return nil, err
	}
	bog := BankGuarantee{}
	json.Unmarshal(bytes, &bog)
	fmt.Println("bog data:", bog)
	bog.Status = status
	fmt.Println("BOG data after status change:", bog)
	s2, _ := json.Marshal(bog)

	err = stub.PutState(bgId, s2)
	if err != nil {
		logger.Error("Could not save Bank Guarantee to ledger", err)
		return nil, err
	}

	return nil, nil
}

func (t *SimpleChaincode) AmendLetterOfCredit(stub shim.ChaincodeStubInterface, args []string) ([]byte, error) {
	logger.Debug("Entering UpdateLetterOfCredit")

	if len(args) < 2 {
		logger.Error("Invalid number of args")
		return nil, errors.New("Expected atleast two arguments for loan application update")
	}

	var lcId = args[0]
	var amendDetails = []byte(args[1])
	fmt.Println("amended data from UI====>  ", args[1])

	lcAmendBytes, err := stub.GetState(lcId)
	if err != nil {
		logger.Error("Could not fetch LC from ledger for amending", err)
		return nil, err
	}

	amendObj := LetterOfCredit{}

	err = json.Unmarshal(amendDetails, &amendObj)
	fmt.Println("====>  ====>  ====>  ====>  ====>  ====>  ====>  ====>  ====>  ")
	fmt.Println("amendDetails====>  ", amendDetails)
	fmt.Println("====>  ====>  ====>  ====>  ====>  ====>  ====>  ====>  ====>  ")
	fmt.Println("amended object====>  ", amendObj)
	fmt.Println("====>  ====>  ====>  ====>  ====>  ====>  ====>  ====>  ====>  ")
	amendLoc := LetterOfCredit{}
	err = json.Unmarshal(lcAmendBytes, &amendLoc)

	amendObjOld := AmendLetterOfCreditDetails{}
	amendObjOld.LcId = amendLoc.LcId
	amendObjOld.LcAmendReqId = amendLoc.LcReqId
	amendObjOld.LcAmount = amendLoc.LcAmount
	amendObjOld.AdvisingBankRef = amendLoc.AdvisingBankRef
	amendObjOld.ModeOfShipment = amendLoc.ModeOfShipment
	amendObjOld.LcExpiryDate = amendLoc.LcExpiryDate
	amendObjOld.AmendmentDetails = amendLoc.AmendmentDetails
	amendObjOld.LcExpiryPlace = amendLoc.LcExpiryPlace
	//amendObjOld.LcNumberOfAmendments, _ =strconv.Atoi(amendLoc.LcNumberOfAmendments)
	amendObjOld.LcNumberOfAmendments = amendLoc.LcNumberOfAmendments
	amendObjOld.Status = amendLoc.Status

	amendLoc.LcAmount = amendObj.LcAmount
	amendLoc.ModeOfShipment = amendObj.ModeOfShipment
	amendLoc.LcExpiryDate = amendObj.LcExpiryDate
	amendLoc.LcExpiryPlace = amendObj.LcExpiryPlace
	amendLoc.LcId = amendObj.LcId
	amendLoc.LcReqId = amendObj.LcReqId
	amendLoc.AdvisingBankRef = amendObj.AdvisingBankRef
	amendLoc.AmendmentDetails = amendObj.AmendmentDetails

	fmt.Println("amended details main, array ====>  ", amendLoc.LcAmount, amendObjOld.LcAmount)
	//  if(amendObj.LcId != ""){
	amendLoc.AmendArray = append(amendLoc.AmendArray, amendObjOld)
	amendLoc.LcNumberOfAmendments = len(amendLoc.AmendArray)
	//   }

	amendLoc.Status = "AMENDED"

	fmt.Println("amended details====>  ", amendLoc.LcAmount)

	fmt.Println("====>  ====>  ====>  ====>  ====>  ====>  ====>  ====>  ====>  ")
	fmt.Println("after forming state to store amendLoc====>  ", amendLoc)
	fmt.Println("====>  ====>  ====>  ====>  ====>  ====>  ====>  ====>  ====>  ")

	lABytes, err := json.Marshal(&amendLoc)
	if err != nil {
		logger.Error("Could not marshal loan application post update", err)
		return nil, err
	}

	err = stub.PutState(lcId, lABytes)
	if err != nil {
		logger.Error("Could not save loan application post update", err)
		return nil, err
	}

	/*var customEvent = "{eventType: 'loanApplicationUpdate', description:" + loanApplicationId + "' Successfully updated status'}"
	err = stub.SetEvent("evtSender", []byte(customEvent))
	if err != nil {
		return nil, err
	}*/

	//t.UpdateStatus(lcId, "AMENDED")
	//res := t.UpdateStatus(lcId, "AMENDED")

	logger.Info("Successfully amended lc application")
	return nil, nil

}

func (t *SimpleChaincode) VerifyBill(stub shim.ChaincodeStubInterface, args []string) ([]byte, error) {
	logger.Debug("Updating lc status from Beneficiary Bank end")
	if len(args) < 1 {
		logger.Error("Invalid number of args")
		return nil, errors.New("Expected atleast two arguments for document upload")
	}
	var lcId = args[0]

	fmt.Printf("verify bill arguements=============>>>>", args[0])
	lcIdAsBytes, err := stub.GetState(lcId)
	logger.Debug("bill IN UPLOAD DOC ***********")
	lcRec := LetterOfCredit{}
	json.Unmarshal(lcIdAsBytes, &lcRec)
	logger.Debug("lcRec  ", lcRec)
	lcRec.Status = "DOCUMENT VERIFIED"
	LCIdArrayAsBytes, _ := json.Marshal(lcRec)
	err = stub.PutState(lcId, LCIdArrayAsBytes)
	if err != nil {
		logger.Error("Could not save status to ledger", err)
		return nil, err
	}
	return nil, nil
}

func (t *SimpleChaincode) LodgeBill(stub shim.ChaincodeStubInterface, args []string) ([]byte, error) {

	logger.Debug("Entering LodgeBill")
	if len(args) < 2 {
		logger.Error("Invalid number of args")
		return nil, errors.New("Expected atleast two arguments for bills creation")
	}
	var lcId = args[0]
	var bill = args[1]

	fmt.Printf("arguements in chaincode==============>>>>", args[0], args[1])

	logger.Debug("bill==========>  ", bill)
	lcIdAsBytes, err := stub.GetState(lcId)
	if err != nil {
		return nil, errors.New("Failed to get LC with the given ID")
	}

	lcRec := LetterOfCredit{}
	json.Unmarshal(lcIdAsBytes, &lcRec)
	logger.Debug("lcRec  ", lcRec)

	var latestBill Bills
	err = json.Unmarshal([]byte(bill), &latestBill)
	logger.Debug("Latest Bill at line 421...", latestBill)

	logger.Debug("Before bills-outstanding logic")
	if latestBill.BillAmount <= lcRec.LcAmount {
		fmt.Printf("Entered bills-outstanding logic.....")

		if len(lcRec.Bill) == 0 {
			logger.Debug("My first bill...", lcRec.Bill)
			latestBill.LcOutstandingAmt = lcRec.LcAmount - latestBill.BillAmount
			lcRec.Bill = append(lcRec.Bill, latestBill)
			logger.Debug("Latest Biil...", latestBill)
			logger.Debug("Lc record and amount", lcRec.LcAmount, latestBill.BillAmount)
		} else if latestBill.BillAmount <= lcRec.Bill[len(lcRec.Bill)-1].LcOutstandingAmt {
			latestBill.LcOutstandingAmt = lcRec.Bill[len(lcRec.Bill)-1].LcOutstandingAmt - latestBill.BillAmount
			lcRec.Bill = append(lcRec.Bill, latestBill)
		}

		if latestBill.LcOutstandingAmt == 0 {
			logger.Debug("Entering LodgeBill - Cleared bill")
			lcRec.Status = "BILL LODGED"
		} else {
			logger.Debug("Entering LodgeBill - bill NOT Cleared")
			lcRec.Status = "BILL PARTIALLY LODGED"
		}
		LCIdArrayAsBytes, _ := json.Marshal(lcRec)
		err = stub.PutState(lcId, LCIdArrayAsBytes)
		if err != nil {
			logger.Error("Could not save bills to ledger", err)
			return nil, err
		}
	}
	return nil, nil
}

func (t *SimpleChaincode) AmendBankGuarantee(stub shim.ChaincodeStubInterface, args []string) ([]byte, error) {
	logger.Debug("Entering BankGuarantee Amend")

	if len(args) < 2 {
		logger.Error("Invalid number of args")
		return nil, errors.New("Expected atleast two arguments for bank guarantee")
	}

	var bgId = args[0]
	var bgAmendDetails = []byte(args[1])
	fmt.Println("amended data from UI====>  ", args[1])

	bgAmendBytes, err := stub.GetState(bgId)
	if err != nil {
		logger.Error("Could not fetch BG from ledger for amending", err)
		return nil, err
	}

	bgAmendObj := BankGuarantee{}

	err = json.Unmarshal(bgAmendDetails, &bgAmendObj)
	fmt.Println("====>  ====>  ====>  ====>  ====>  ====>  ====>  ====>  ====>  ")
	fmt.Println("bgAmendDetails====>  ", bgAmendDetails)
	fmt.Println("====>  ====>  ====>  ====>  ====>  ====>  ====>  ====>  ====>  ")
	fmt.Println("amended object====>  ", bgAmendObj)
	fmt.Println("====>  ====>  ====>  ====>  ====>  ====>  ====>  ====>  ====>  ")
	amendBog := BankGuarantee{}
	err = json.Unmarshal(bgAmendBytes, &amendBog)

	bgAmendObjOld := AmendBankGuaranteeDetails{}
	bgAmendObjOld.BgId = amendBog.BgId
	bgAmendObjOld.BgAmendReqId = amendBog.BgReqId
	bgAmendObjOld.PrincipalAmount = amendBog.PrincipalAmount
	bgAmendObjOld.ExpiryDate = amendBog.ExpiryDate
	bgAmendObjOld.TermsAndConditions = amendBog.TermsAndConditions
	bgAmendObjOld.BgNumberOfAmendments = amendBog.BgNumberOfAmendments
	bgAmendObjOld.Status = amendBog.Status

	amendBog.PrincipalAmount = bgAmendObj.PrincipalAmount
	amendBog.TermsAndConditions = bgAmendObj.TermsAndConditions
	amendBog.ExpiryDate = bgAmendObj.ExpiryDate
	amendBog.BgId = bgAmendObj.BgId
	amendBog.BgReqId = bgAmendObj.BgReqId

	fmt.Println("amended details main, array ====>  ", amendBog.PrincipalAmount, bgAmendObjOld.PrincipalAmount)
	amendBog.BGAmendArray = append(amendBog.BGAmendArray, bgAmendObjOld)
	amendBog.BgNumberOfAmendments = len(amendBog.BGAmendArray)

	amendBog.Status = "AMENDED"

	fmt.Println("amended details====>  ", amendBog.PrincipalAmount)

	fmt.Println("====>  ====>  ====>  ====>  ====>  ====>  ====>  ====>  ====>  ")
	fmt.Println("after forming state to store amendBog====>  ", amendBog)
	fmt.Println("====>  ====>  ====>  ====>  ====>  ====>  ====>  ====>  ====>  ")

	bABytes, err := json.Marshal(&amendBog)
	if err != nil {
		logger.Error("Could not marshal bg post update", err)
		return nil, err
	}

	err = stub.PutState(bgId, bABytes)
	if err != nil {
		logger.Error("Could not save bg details post update", err)
		return nil, err
	}

	logger.Info("Successfully amended bg application")
	return nil, nil

}

//END HERE

func main() {
	err := shim.Start(new(SimpleChaincode))
	if err != nil {
		fmt.Printf("Error starting Simple chaincode: %s", err)
	}
}
