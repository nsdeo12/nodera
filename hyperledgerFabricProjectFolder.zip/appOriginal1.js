var express = require('express');
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var cors=require('cors');
var bodyParser = require('body-parser');
var parseJson = require('parse-json');

var routes = require('./routes/index');
var users = require('./routes/users');
var dishrouter = require('./routes/dishrouter');
var promorouter = require('./routes/promorouter');
var leaderrouter = require('./routes/leaderrouter');
//var customerRouter=require('./routes/customerRouter');
//var employeeRouter=require('./routes/employeeRouter');
var morgan         = require('morgan');        // log requests to the console (express4)
var bodyParser     = require('body-parser');     // pull information from HTML POST (express4)
//  var methodOverride = require('method-override'); // simulate DELETE and PUT (express4)
	var fs = require('fs');


	                var nodemailer = require('nodemailer');
    var smtpTransport = require('nodemailer-smtp-transport');
    var smtpPool = require('nodemailer-smtp-pool');

                                var transporter = nodemailer.createTransport(
            smtpPool({
               host: 'localhost',
               port: 1025,
               ignoreTLS: true
            })
        );


var betabank = express();
betabank.use(cors());





 var inf;
 betabank.use(morgan('dev'));
	betabank.use(bodyParser.urlencoded({'extended':'true'}));            // parse application/x-www-form-urlencoded
	betabank.use(bodyParser.json());                                     // parse application/json
	betabank.use(bodyParser.json({ type: 'application/vnd.api+json' })); // parse application/vnd.api+json as json


var Ibc1 = require('ibm-blockchain-js');                                                                                                                                                                                                                  //rest based SDK for ibm blockchain
var ibc = new Ibc1();



try{
							//this hard coded list is intentionaly left here, feel free to use it when initially starting out
							//please create your own network when you are up and running
							var manual = JSON.parse(fs.readFileSync('mycreds_docker_compose.json', 'utf8'));
							//var manual = JSON.parse(fs.readFileSync('mycreds.json', 'utf8'));
							//var manual = JSON.parse(fs.readFileSync('testcreds.json', 'utf8'));
							//var manual = JSON.parse(fs.readFileSync('mycreds_bluemix.json', 'utf8'));
							var peers = manual.credentials.peers;
							//console.log('loading hardcoded peers',peers);
							var users = null;                                                                                                                                                                                                                                                                                                                //users are only found if security is on
							if(manual.credentials.users) users = manual.credentials.users;
							//console.log('loading hardcoded users',users);
}
catch(e){
							//console.log('Error - could not find hardcoded peers/users, this is okay if running in bluemix');
}




// view engine setup
betabank.set('views', path.join(__dirname, 'views'));
betabank.set('view engine', 'jade');



// uncomment after placing your favicon in /public
//alfabank.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));
betabank.use(logger('dev'));
betabank.use(bodyParser.json());
betabank.use(bodyParser.urlencoded({
	extended: false
}));
betabank.use(cookieParser());
betabank.use(express.static(path.join(__dirname, 'public')));






//alfabank.use('/', routes);

//alfabank.use('/users', users);
//alfabank.use('/dishes',dishrouter);
//alfabank.use('/leaders',leaderrouter);
//alfabank.use('/promos',promorouter);

//alfabank.use('/customer',customerRouter);
//alfabank.use('/employee',employeeRouter);



var mysql = require('mysql');
var shareddb = mysql.createPool({
	connectionLimit: 150000,
	host: 'localhost',
	user: 'root',
	password: 'Admin123',
	database: 'shareddb'
});



var beneficiarybank = mysql.createPool({
	connectionLimit: 150000,
	host: 'localhost',
	user: 'root',
	password: 'Admin123',
	database: 'beneficiarybank'
});



var applicantbank = mysql.createPool({
	connectionLimit: 150000,
	host: 'localhost',
	user: 'root',
	password: 'Admin123',
	database: 'applicantbank'
});



var chaincode  = null;
var ccdeployed = null;
var parseval = null;


var options =      {
network:{
			peers: [

															{
																				"api_host": "192.168.99.100", //replace with your hostname or ip of a peer                                        //replace with your https port (optional, omit if n/a)
																				"api_port": 8050,        //replace with your http port
																				"type": "peer",
																				"id": "jdpe"             //unique id of peer
															}
					],                                                                                                                                                                                                                                                                             //lets only use the first peer! since we really don't need any more than 1
					users: [

															{
																				"enrollId": "alice",
																				"enrollSecret": "CMS10pEQlB16"
															}
													]
				,
				//dump the whole thing, sdk will parse for a good one
			options: {
				quiet: true,                                                                                                                                                                                                                                         //detailed debug messages on/off true/false
				tls: false,                                                                                                                                                                              //should app to peer communication use tls?
				maxRetry: 1                                                                                                                                                                                                                                                        //how many times should we retry register before giving up
					},
},
chaincode:{
			//zip_url: 'https://github.com/ibm-blockchain/marbles/archive/v2.0.zip',
																																																																																																					//subdirectroy name of chaincode after unzipped
			//git_url: 'http://gopkg.in/ibm-blockchain/marbles.v2/chaincode',                                                                                         //GO get http url

			 git_url:'https://github.com/bminchal/chain1/blob/master/git_code/',
			zip_url: 'https://github.com/bminchal/chain1/archive/master.zip',
			//unzip_dir: 'marbles-2.0/chaincode',
			unzip_dir: '/chain1-master/git_code/',

			 deployed_name: '7b2f6b588651f95d691bc7d1af651ca66e8511da99b66a1e2f0493b03cf07dbc0e5f8a70d0190e8c09c2a32ba533109d8f4d6864168b0e2e64697a1e851747c3',


			//hashed cc name from prev deployment, comment me out to always deploy, uncomment me when its already deployed to skip deploying again
			//deployed_name: '16e655c0fce6a9882896d3d6d11f7dcd4f45027fd4764004440ff1e61340910a9d67685c4bb723272a497f3cf428e6cf6b009618612220e1471e03b6c0aa76cb'
}
};

// ---- Fire off SDK ---- //



//// Post method /////

// create todo and send back all todos after creation
																																																																																																							//sdk will populate this var in time, lets give it high scope by creating it here
ibc.load(options, function (err, cc ){     //parse/load chaincode, response has chaincode functions!
							if(err != null){
															//console.log("options===>",options);

															//console.log('! looks like an error loading the chaincode or network, app will fail\n', err);
							}
							else{
															chaincode = cc;



															// ---- To Deploy or Not to Deploy ---- //
															if(!cc.details.deployed_name || cc.details.deployed_name === ''){                                                                         //yes, go deploy
																							cc.deploy('init', ['99'], {delay_ms: 30000}, function(e){                                                                                    //delay_ms is milliseconds to wait after deploy for conatiner to start, 50sec recommended
																															check_if_deployed(e, 1);
																							});
															}
															else{                                                                                                                                                                                                                                                                                                                      //no, already deployed
																							//console.log('chaincode summary file indicates chaincode has been previously deployed');
																							check_if_deployed(null, 1);
															}
							}
});


//loop here, check if chaincode is up and running or not

function check_if_deployed(e, attempt){
							if(e){
															cb_deployed(e);                                                                                                                                                                                                                                                                                              //looks like an error pass it along
							}

							cb_deployed(null);


}


function cb_deployed(e){
							if(e != null){
															//look at tutorial_part1.md in the trouble shooting section for help
															//console.log('! looks like a deploy error, holding off on the starting the socket\n', e);
							}
							else{
															console.log('------------------------------------------ Service Up ------------------------------------------');

															ccdeployed = "deployed";

							}


}


 betabank.post('/lc-open', function(req, res) {


	 var loc = req.body;
	//console.log("TEXT FROM UI",loc);

				var ID = loc.lcId;
				var LCID = loc.lcId;
				var LCREQ = loc.lcReqId;
				//console.log("LCID",LCID);
				//console.log("LCREQ",loc.lcreqid);


beneficiarybank.query("UPDATE letterofcredit SET status ='OPENED' WHERE lcreqid = ?", [LCREQ], function(err, result){
  if(err) throw err;


//console.log('updated of record:', result);


});


		var input  = JSON.stringify(loc);
		chaincode.invoke.OpenLetterOfCredit([ID, input]);
		var response = res.end(ID+" has been Opened successfully");

				var fromId = "admin@"+loc.applicantBank.toLowerCase()+".com";
			    var to = {"one":loc.applicantCustomer.toLowerCase()+"@mail.com", "two" : "admin@"+loc.advisingBankID.toLowerCase()+".com", "three" : loc.beneficiaryId.toLowerCase()+"@mail.com"}; 
				var stat = "Requesting for LC Status - opened";
				var msg = "Hi,\n I have opened for LC. Kindly process. "+loc.lcId+" is opened";

                              sendEmail(fromId, to, stat, msg);


		return response;


							 /* chaincode.invoke.OpenLetterOfCredit([ID, input],function(err, resp){
					//console.log("RESPONSE  ",resp);
					var response = res.end(toString(resp));
					//console.log("response",resp);
					//var response = res.end("LC-ID",ID ,"CREATED SUCCESSFULY");
																return response;
				});*/



});
betabank.post('/bg-open', function(req, res) {
	 var bog = req.body;
	//console.log("TEXT FROM UI======================>>>>>>>>>>>>>>>>>>>",bog);

				var ID = bog.bgId;
				var BGID = bog.bgId;
				var BGREQ = bog.bgReqID;
				//console.log("ID=========================>>>>",ID);
				//console.log("BGID=========================>>>>",BGID);
				//console.log("BGREQ=========================>>>>",BGREQ);

beneficiarybank.query("UPDATE bankguarantee SET status ='OPENED' WHERE bgReqID = ?", [BGREQ], function(err, result){
  if(err) throw err;


////console.log('updated of record:', result);

});

		var input  = JSON.stringify(bog);
		//console.log("ID================>>",ID);
		//console.log("input================>>",input);
		chaincode.invoke.OpenBankGuarantee([ID, input]);
		var response = res.send(ID+" has been Opened successfully");

		 var fromId = "admin@"+bog.applicantBank.toLowerCase()+".com";
		  var to = {"one":bog.applicantCustomer.toLowerCase()+"@mail.com", "two" : "admin@"+bog.advisingBankID.toLowerCase()+".com", "three" : loc.beneficiaryId.toLowerCase()+"@mail.com"}; 
		 var stat = "Requesting for BG Status - opened";
				var msg = "Hi,\n I have opened for BG. Kindly process. "+bog.bgId+" is opened";

                         sendEmail(fromId, to, stat, msg);


		return response;


							 chaincode.invoke.OpenLetterOfCredit([ID, input],function(err, resp){
					console.log("RESPONSE  ",resp);
					var response = res.end(toString(resp));
					console.log("response",resp);
					//var response = res.end("LC-ID",ID ,"CREATED SUCCESSFULY");
																return response;
				});



});


 betabank.get('/api/GetLcById/:id', function(req, res) {

	idValue = req.params.id
	//console.log("idValue",idValue);
chaincode.query.GetLcById([idValue], function(err, resp){

							if(resp != null){
							//console.log("resp ===>",resp);
							var parseval = JSON.parse(resp);
							//console.log("parseval ==>",parseval);
							var info = {
														"DATA": parseval
										 };
							res.json(info);





															}
							});
});

betabank.get('/api/GetBgById/:id', function(req, res) {

	idValue = req.params.id
	console.log("idValue",idValue);
chaincode.query.GetBgById([idValue], function(err, resp){

							if(resp != null){
							//console.log("resp ===>",resp);
							var parseval = JSON.parse(resp);
							//console.log("parseval ==>",parseval);
							var info = {
														"DATA": parseval
										 };
							res.json(info);





															}
							});
});



 betabank.get('/lc-orders', function(getreqang, getresang) {

chaincode.query.GetAllLC([''], function(err, resp){

	//console.log("resp.length ===>===>===>===>===>===>===>===>===>===>===>===>===>===>===>===>");
//console.log("resp.length ===>",resp.length);
	//					 console.log("resp.length ===>===>===>===>===>===>===>===>===>===>===>===>===>===>===>===>");
		//					console.log("resp ===>",resp);
//console.log("resp.length ===>===>===>===>===>===>===>===>===>===>===>===>===>===>===>===>");

/* 							                  console.log("resp[0] ===>",resp[0]);
console.log("resp.length ===>===>===>===>===>===>===>===>===>===>===>===>===>===>===>===>");
															console.log("resp[n-1] ===>",resp[resp.length-1]);
															console.log("resp[n-2] ===>",resp[resp.length-2]);
console.log("resp.length ===>===>===>===>===>===>===>===>===>===>===>===>===>===>===>===>");    */




							//console.log("resp ===>",resp);
							if(resp != null){
				//console.log("resp ===>",resp);
				var sTemp = "";
				var aObjs = [];
									 var stop = 0;
			for(var i=0; i<resp.length; ++i)
			{
				sTemp += resp[i];

				if(resp[i] == "{")
				{
					stop++;
			}
				if(resp[i] == "}")
				{
					stop--;
			}
				if ((resp[i] == "}") && (stop==0))
				{
				aObjs.push(JSON.parse(sTemp));
				sTemp = "";
				//console.log("aObjs inside2222222222222222222222222222",aObjs);
				}
			}

							//console.log("aObjs", aObjs);
							getresang.json(aObjs);
							//getresang.send(parseval2);

							}
});
});


betabank.get('/bg-orders', function(getreqang, getresang) {

chaincode.query.GetAllBG([''], function(err, resp){
//console.log("resp ===>",resp);
	//console.log("resp.length ===>===>===>===>===>===>===>===>===>===>===>===>===>===>===>===>");
//console.log("resp.length ===>",resp.length);
						 //console.log("resp.length ===>===>===>===>===>===>===>===>===>===>===>===>===>===>===>===>");

//console.log("resp.length ===>===>===>===>===>===>===>===>===>===>===>===>===>===>===>===>");

/* 							                  console.log("resp[0] ===>",resp[0]);
console.log("resp.length ===>===>===>===>===>===>===>===>===>===>===>===>===>===>===>===>");
															console.log("resp[n-1] ===>",resp[resp.length-1]);
															console.log("resp[n-2] ===>",resp[resp.length-2]);
console.log("resp.length ===>===>===>===>===>===>===>===>===>===>===>===>===>===>===>===>");    */


							//console.log("resp ===>",resp);
							if(resp != null){
			//	console.log("resp ===>",resp);
				var sTemp = "";
				var aObjs = [];
									 var stop = 0;
			for(var i=0; i<resp.length; ++i)
			{
				sTemp += resp[i];

				if(resp[i] == "{")
				{
					stop++;
			}
				if(resp[i] == "}")
				{
					stop--;
			}
				if ((resp[i] == "}") && (stop==0))
				{
				aObjs.push(JSON.parse(sTemp));
				sTemp = "";
				//console.log("aObjs inside2222222222222222222222222222",aObjs);
				}
			}

							//console.log("aObjs", aObjs);
							getresang.json(aObjs);
							//getresang.send(parseval2);

							}
});
});



betabank.get('/customer-lc-orders/:custName', function(getreqang, getresang) {
		 customerName = getreqang.params.custName
chaincode.query.GetCustomerBasedRecords([customerName], function(err, resp){
							//console.log("resp ===>",resp);
							if(resp != null){
				//console.log("resp ===>",resp);
				var sTemp = "";
				var aObjs = [];
									 var stop = 0;
			for(var i=0; i<resp.length; ++i)
			{
				sTemp += resp[i];

				if(resp[i] == "{")
				{
					stop++;
			}
				if(resp[i] == "}")
				{
					stop--;
			}
				if ((resp[i] == "}") && (stop==0))
				{
				aObjs.push(JSON.parse(sTemp));
				sTemp = "";
				//console.log("aObjs inside2222222222222222222222222222",aObjs);
				}
			}

							//console.log("aObjs", aObjs);
							getresang.json(aObjs);
							//getresang.send(parseval2);

							}
});
});

betabank.get('/customer-bg-orders/:custName', function(getreqang, getresang) {
		 customerName = getreqang.params.custName
chaincode.query.GetCustomerBasedBgRecords([customerName], function(err, resp){
							//console.log("resp ===>",resp);
							if(resp != null){
				//console.log("resp ===>",resp);
				var sTemp = "";
				var aObjs = [];
									 var stop = 0;
			for(var i=0; i<resp.length; ++i)
			{
				sTemp += resp[i];

				if(resp[i] == "{")
				{
					stop++;
			}
				if(resp[i] == "}")
				{
					stop--;
			}
				if ((resp[i] == "}") && (stop==0))
				{
				aObjs.push(JSON.parse(sTemp));
				sTemp = "";
				}
			}

							getresang.json(aObjs);


							}
});
});




 betabank.post('/lcamendreq', function(postreqang, postresang) {
	var uidata = postreqang.body;
	 //console.log("uidata-----------------------------",uidata)
	var amendRecord= [{
		"lcAmendId" : uidata.lcAmendId,
				"lcAmendReqId" : uidata.lcAmendReqId,
				"numberOfAmendment" : uidata.numberOfAmendment,
				"lcAmendAmount" : uidata.lcAmendAmount,
				"lcAmendAdvisingBankRef" : uidata.lcAmendAdvisingBankRef,
				"amendModeOfShipment" : uidata.amendModeOfShipment,
				"lcAmendExpiryDate" : uidata.lcAmendExpiryDate,
				"lcAmendExpiryPlace" : uidata.lcAmendExpiryPlace,
				"amendmentDetails" : uidata.amendmentDetails,
				"status" : "AmendRequested"
				/*
				"applicantCustomer" : uidata.applicantCustomer,
				"applicantBank" : uidata.applicantBank,
				"advisingBankID" : uidata.advisingBankID,
				"beneficiaryId" : uidata.beneficiaryId
				*/
	}];

	beneficiarybank.query('INSERT INTO letterofcreditamend SET ?', amendRecord, function(err,res){
			if(err) throw err;
			var response = postresang.end(uidata.lcAmendReqId+" has been Requested successfully");

				var fromId = uidata.applicantCustomer.toLowerCase()+"@mail.com";
			    var to = {"one":"admin@"+uidata.applicantBank.toLowerCase()+".com", "two" : "admin@"+uidata.advisingBankID.toLowerCase()+".com", "three" : uidata.beneficiaryId.toLowerCase()+"@mail.com"}; 
				var stat = "Requesting for amend the LC";
				var msg = "Hi,\n I have requested for amendment of LC. Kindly process the amendment for LD id. "+uidata.lcAmendId+" is requested";

                              sendEmail(fromId, to, stat, msg);

	return response;
	});
});


betabank.post('/bgamendreq', function(postreqang, postresang) {
	var uidata = postreqang.body;
	 console.log("uidata-----------------------------",uidata)
	var bgAmendRecord= [{
				"bgAmendId" : uidata.bgAmendId,
				"bgAmendReqId" : uidata.bgAmendReqId,
				"numberOfAmendment" : uidata.numberOfAmendment,
				"bgAmendPrincipalAmount" : uidata.bgAmendPrincipalAmount,
				"bgAmendExpiryDate" : uidata.bgAmendExpiryDate,
				"bgTermsAndConditions" : uidata.bgTermsAndConditions,
				"status" : "AMEND REQUESTED"
	}];

	beneficiarybank.query('INSERT INTO bankguaranteeamend SET ?', bgAmendRecord, function(err,res){
			if(err) throw err;
			var response = postresang.end(uidata.bgAmendReqId+" has been Requested successfully");

				var fromId = uidata.ApplicantCustomer.toLowerCase()+"@mail.com";
			    var to = {"one":"admin@"+uidata.ApplicantBank.toLowerCase()+".com", "two" : "admin@"+uidata.BeneficiaryBank.toLowerCase()+".com", "three" : uidata.Beneficiary.toLowerCase()+"@mail.com"}; 
				var stat = "Requesting for amend the BG";
				var msg = "Hi,\n I have requested for amendment of BG. Kindly process the amendment for BG id. "+uidata.bgAmendId+" is requested";

                              sendEmail(fromId, to, stat, msg);

	return response;
	});
});


 betabank.get('/lcamendreq',function (req, res) {
	var queryString = "SELECT * FROM letterofcreditamend where status='AmendRequested' ";

	beneficiarybank.getConnection(function(err, connection) {
		if (err) {
            //connection.release();
            res.json({ "code": 100, "status": "Error in connection database" });
            return;
        }
		connection.query(queryString, function(err, rows, fields) {
			if (err){
				res.send("FAILURE");
			}
			connection.release();
			if(rows.length <=0){
				res.send(" [ { Result: 'Failure' } ]");
				return;
			}
			else{
				res.send(rows);
				return
				}
		//connection.release();
		});
	});
});

betabank.get('/bgamendreq',function (req, res) {
	var queryString = "SELECT * FROM bankguaranteeamend where status='AMEND REQUESTED'";

	beneficiarybank.getConnection(function(err, connection) {
		if (err) {
            //connection.release();
            res.json({ "code": 100, "status": "Error in connection database" });
            return;
        }
		connection.query(queryString, function(err, rows, fields) {
			if (err){
				res.send("FAILURE");
			}
			connection.release();
			if(rows.length <=0){
				res.send(" [ { Result: 'Failure' } ]");
				return;
			}
			else{
				res.send(rows);
				return
				}
		//connection.release();
		});
	});
});

 betabank.get('/lcamendreq/:lcAmendReqId', function(req, res) {
	var param = req.params.lcAmendReqId;
	var queryString ='select * from letterofcreditamend where lcAmendReqId=?';

	beneficiarybank.getConnection(function(err, connection) {
		if (err) {
            //connection.release();
            res.json({ "code": 100, "status": "Error in connection database" });
            return;
        }
		connection.query(queryString, [param], function(err, rows, fields) {
			if (err) {
				res.send("FAILURE");
			}
			connection.release();
			if (rows.length <= 0) {
				res.send(" [ { Result: 'Failure' } ]");
				return;
			} else {
				res.send(rows);
				return
			}
			//connection.release();
		});
	});
			});

betabank.get('/bgamendreq/:bgAmendReqId', function(req, res) {
	var param = req.params.bgAmendReqId;
	var queryString ='select * from bankguaranteeamend where bgAmendReqId=?';

	beneficiarybank.getConnection(function(err, connection) {
		if (err) {
            //connection.release();
            res.json({ "code": 100, "status": "Error in connection database" });
            return;
        }
		connection.query(queryString, [param], function(err, rows, fields) {
			if (err) {
				res.send("FAILURE");
			}
			connection.release();
			if (rows.length <= 0) {
				res.send(" [ { Result: 'Failure' } ]");
				return;
			} else {
				res.send(rows);
				return
			}
			//connection.release();
		});
	});
			});




 betabank.post('/lc-amend', function(req, res) {
	var loc = req.body;
	var ID = loc.lcId;
var LCID = loc.lcId;
var LCREQ = loc.lcReqId;

//console.log("loc OBJECT",loc);



					//	UPDATE  letterofcreditamend SET status='amended' , lcAmendId=? where lcAmendReqId=?
beneficiarybank.query("UPDATE letterofcreditamend SET status ='AMENDED' WHERE lcAmendReqId  = ? AND lcAmendId=? ", [LCREQ,LCID], function(err, result){
							 if(err) throw err;
							 //console.log('updated of record:', result);
			});


	var input  = JSON.stringify(loc);
//console.log("input OBJECT",input);
chaincode.invoke.AmendLetterOfCredit([ID, input]);
	var response = res.end(ID+" has been Amended successfully");

					var fromId = "admin@"+loc.applicantBank.toLowerCase()+".com";
			    var to = {"one":loc.applicantCustomer.toLowerCase()+"@mail.com", "two" : "admin@"+loc.advisingBankID.toLowerCase()+".com", "three" : loc.beneficiaryId.toLowerCase()+"@mail.com"}; 
				var stat = "Requesting for LC Status - Amended";
				var msg = "Hi,\n I have amended the LC. Kindly approve. "+loc.lcReqId+" is amended";

                              sendEmail(fromId, to, stat, msg);

	return response;
});

betabank.post('/bg-amend', function(req, res) {
	var bog = req.body;
	console.log('request body============>>>>>', bog);

	var ID = bog.bgId;
var BGID = bog.bgId;
var BGREQ = bog.bgReqID+"-00"+bog.bgNumberOfAmendments;

					console.log('updated of record bgAmendReqId:', BGREQ);
					console.log('updated of record:bgAmendId', BGID);

					beneficiarybank.query("UPDATE bankguaranteeamend SET status ='AMENDED' WHERE bgAmendReqId = ? AND bgAmendId=? ", [BGREQ,BGID], function(err, result){
							 if(err) throw err;
							 console.log('updated of record:', result);
			});


	var input  = JSON.stringify(bog);
//console.log("input OBJECT",input);
chaincode.invoke.AmendBankGuarantee([ID, input]);
	var response = res.end(ID+" has been Amended successfully");

					var fromId = bog.applicantCustomer.toLowerCase()+"@mail.com";
			    var to = {"one":"admin@"+bog.applicantBank.toLowerCase()+".com", "two" : "admin@"+bog.beneficiaryBank.toLowerCase()+".com", "three" : bog.beneficiary.toLowerCase()+"@mail.com"}; 
				var stat = "Requesting for BG Status - Amended";
				var msg = "Hi,\n I have amended the BG. Kindly approve. "+bog.bgReqID+" is amended";

                              sendEmail(fromId, to, stat, msg);

	return response;
});


betabank.post('/lc-approve', function(getreqang, getresang) {
		 var input = getreqang.body;

//console.log("input   ",input);
							 chaincode.invoke.UpdateStatus([input.lcId, input.status]);
															 var response = getresang.end(input.lcId+" has been Approved successfully");

				var fromId = "admin@"+input.advisingBankID.toLowerCase()+".com";
			    var to = {"one":input.applicantCustomer.toLowerCase()+"@mail.com", "two" : "admin@"+input.applicantBank.toLowerCase()+".com", "three" : input.beneficiaryId.toLowerCase()+"@mail.com"}; 
				var stat = "Requesting for LC Status - Approved";
				var msg = "Hi,\n I have approved for LC. Kindly process. "+input.lcId+" is Approved";

                              sendEmail(fromId, to, stat, msg);

																return response;
});

betabank.post('/bg-approve', function(getreqang, getresang) {
		 var input = getreqang.body;
		 console.log("response of bg and bgid",input.bgID,input.status);

//console.log("input bg approveBG  ",input.bgId,input.status);
							 chaincode.invoke.BGApprove([input.bgID,input.status]);
															 var response = getresang.end(input.bgID+" has been Approved successfully");

				// var fromId = "admin@"+input.advisingBankID.toLowerCase()+".com";
			  //   var to = {"one":input.applicantCustomer.toLowerCase()+"@mail.com", "two" : "admin@"+input.applicantBank.toLowerCase()+".com", "three" : input.beneficiaryId.toLowerCase()+"@mail.com"}; 
				// var stat = "Requesting for BG Status - Approved";
				// var msg = "Hi,\n I have approved for BG. Kindly process. "+input.bgReqId+" is Approved";
				//
        //                       sendEmail(fromId, to, stat, msg);

																return response;
});

betabank.get('/', function(req, res) {
	res.sendFile(path.join(__dirname + '/index.html'));
});


 betabank.get('/test', function(req, res) {

});

 betabank.get('/me', function(req, res) {

	res.send("BETABank");

});




 betabank.get('/lcRequestID', function(req, res) {

	var hrTime = process.hrtime();
	var temp = hrTime[0] * 1000000 + hrTime[1] / 1000;
	////console.log(hrTime[0] * 1000000 + hrTime[1] / 1000)
	res.send(Math.floor(temp).toString());

});





 betabank.get('/customer/:email', function(req, res) {
	var param = req.params.email;
	//console.log("email ",param);
	//test(param);
	var queryString = "SELECT name FROM CUSTOMER WHERE EMAIL=? AND bank='BETABank'";
	////console.log(queryString);

	shareddb.getConnection(function(err, connection) {
		if (err) {
            //connection.release();
            res.json({ "code": 100, "status": "Error in connection database" });
            return;
        }
		connection.query(queryString, [param], function(err, rows, fields) {
			if (err) {
				res.send("FAILURE");
			}
			////console.log("Login Customer ", rows);
			connection.release();
			if (rows.length <= 0) {
				res.send(" [ { Result: 'Failure' } ]");
				return;
			} else {
				res.send(rows);
				return
			}

			
		});
	});

});








betabank.get('/employee/:emailid', function(req, res) {
	var param = req.params.emailid;
	//console.log("URL ROUT ", param);



	var queryString = 'SELECT name FROM EMPLOYEE WHERE EMAIL=?';
	////console.log(queryString);

	beneficiarybank.getConnection(function(err, connection) {
		if (err) {
            //connection.release();
            res.json({ "code": 100, "status": "Error in connection database" });
            return;
        }
		connection.query(queryString, [param], function(err, rows, fields) {
			if (err) {
				res.send("FAILURE");
				}
			////console.log("Login EMPLOYEE ", rows);
			connection.release();
			if (rows.length <= 0) {
				res.send(" [ { Result: 'Failure' } ]");
				return;
			} else {
				res.send(rows);
				return
			}

			//connection.release();
		});

	});
});




betabank.get('/customer/detail/id/:name', function(req, res) {
	var param = req.params.name;
	////console.log("name ", param);
	var queryString = 'SELECT * FROM CUSTOMER WHERE NAME=?';
	////console.log(queryString);
	shareddb.getConnection(function(err, connection) {
		if (err) {
            //connection.release();
            res.json({ "code": 100, "status": "Error in connection database" });
            return;
        }
		connection.query(queryString, [param], function(err, rows, fields) {
			if (err) {
				res.send("FAILURE");
			}
			////console.log("Login EMPLOYEE ", rows);
			connection.release();
			if (rows.length <= 0) {
				res.send(" [ { Result: 'Failure' } ]");
				return;
			} else {
				res.send(rows);
				return
			}

			//connection.release();
		});

	});

});



betabank.get('/othercustomer', function(req, res) {
	var queryString ='SELECT * FROM CUSTOMER WHERE bank !=?';
	////console.log(queryString);
	var bank='BETABank';
	shareddb.getConnection(function(err, connection) {
		if (err) {
            //connection.release();
            res.json({ "code": 100, "status": "Error in connection database" });
            return;
        }
		connection.query(queryString, [bank], function(err, rows, fields) {
			if (err) {
				res.send("FAILURE");
			}
			////console.log("Login EMPLOYEE ", rows);
			connection.release();
			if (rows.length <= 0) {
				res.send(" [ { Result: 'Failure' } ]");
				return;
			} else {
				res.send(rows);
				return
			}

			//connection.release();
		});

	});


});

betabank.get('/customer/detail/:ibanValue', function(req, res) {
	var param = req.params.ibanValue;

	var queryString ='SELECT * FROM CUSTOMER WHERE IBANNO=?';
	////console.log(queryString);

	shareddb.getConnection(function(err, connection) {
		if (err) {
            //connection.release();
            res.json({ "code": 100, "status": "Error in connection database" });
            return;
        }
		connection.query(queryString, [param], function(err, rows, fields) {
			if (err) {
				res.send("FAILURE");
			}
			//console.log("Login EMPLOYEE ", rows);
			connection.release();
			if (rows.length <= 0) {
				res.send(" [ { Result: 'Failure' } ]");
				return;
			} else {
				res.send(rows);
				return
			}

			//connection.release();
		});

	});


});



betabank.get('/employee-lc-orders/:LCApprovalId', function(req, res) {
idValue = req.params.LCApprovalId
	//console.log("idValue",idValue);
chaincode.query.GetLcById([idValue], function(err, resp){

							if(resp != null){
							//console.log("resp ===>",resp);
							var parseval = JSON.parse(resp);
							//console.log("parseval ==>",parseval);
							var info = {
														"DATA": parseval
										 };
							res.json(info);




															}
							});


});
betabank.get('/employee-bg-orders/:BGApprovalId', function(req, res) {
idValue = req.params.BGApprovalId;
	//console.log("idValue",idValue);
chaincode.query.GetBgById([idValue], function(err, resp){

							if(resp != null){
							////console.log("resp ===>",resp);
							var parseval = JSON.parse(resp);
							//console.log("parseval ==>",parseval);
							var info = {
														"DATA": parseval
										 };
							res.json(info);




															}
							});


});

betabank.post('/lcreq', function(postreqang, postresang) {
	 var inf = postreqang.body;
	 //console.log("TEXT FROM UI",inf);

			var uidata = inf;

					 //console.log("chaincode in uidata===>",uidata);

					var record= [{
						 "lcReqId" : uidata.lcReqId,
			"applicantCustomer" : uidata.applicantCustomer,
			"applicantAddress" : uidata.applicantAddress,

			"lcExpiryDate" : uidata.lcExpiryDate ,
			"modeOfShipment" :uidata.modeOfShipment,
			"beneficiaryId" : uidata.beneficiaryId,
			"beneficiaryAddress" : uidata.beneficiaryAddress,
			"lcType" : uidata.lcType,
			"lcCurrency" : uidata.lcCurrency,
			"lcAmount" : uidata.lcAmount,
			"lcIssueDate" :  uidata.lcIssueDate,
		 "lcExpiryPlace" : uidata.lcExpiryPlace,
			"latestShipmentDate" : uidata.latestShipmentDate,
			"liabilityReversalDate" : uidata.liabilityReversalDate,
			"advisingBankID" : uidata.advisingBankID,
			"applicantBank" : uidata.applicantBank,
			"applicantBankAddress" : uidata.applicantBankAddress,
			"advisingBankAddress" : uidata.advisingBankAddress,
			"formofDocumentaryCredit" : uidata.formofDocumentaryCredit,
			"documentaryCreditNumber" : uidata.documentaryCreditNumber,
			"availableWithBy" : uidata.availableWithBy,
			"forTransportationTo" : uidata.forTransportationTo,
			"descriptionOfGoodsAndOrServices" : uidata.descriptionOfGoodsAndOrServices,
			"additionalConditions" : uidata.additionalConditions,
			"periodForPresentation" : uidata.periodForPresentation,
			"advisingThroughBank" : uidata.advisingThroughBank,
			"transshipment" : uidata.transshipment,
			"portofLoading": uidata.portofLoading,
			"maximumCreditAmount" : uidata.maximumCreditAmount,

			//New Changes :Deepak :begin 24-03-2017

			"draftsAtSight" : uidata.draftsAtSight,
			"draftsAtUsance" :  uidata.draftsAtUsance,
			"shipmentPeriodSight" : uidata.shipmentPeriodSight,
			"shipmentPeriodUsance" : uidata.shipmentPeriodUsance,
			"percentageSight" : uidata.percentageSight,
			"percentageUsance" :uidata.percentageUsance,
			"lcAmountSight" : uidata.lcAmountSight,
			"lcAmountUsance" : uidata.lcAmountUsance,

			//New Changes :Deepak :End 24-03-2017

			"partialShipments" : uidata.partialShipments,
			"senderToReceiverInformation" : uidata.senderToReceiverInformation,
			"charges" : uidata.charges,
			"confirmationInstructions" : uidata.confirmationInstructions,
			"sequenceOfTotal" : uidata.sequenceOfTotal,
			"ibanNumber" : uidata.ibanNumber,
			"incoTerms":uidata.incoTerms,
			"status" : "requested",
					}];

					// //console.log("chaincode in invoke===>",chaincode);

				 beneficiarybank.query('INSERT INTO letterofcredit SET ?', record, function(err,res){
				if(err) throw err;
				var fromId = uidata.applicantCustomer.toLowerCase()+"@mail.com";
			    var to = {"one":"admin@"+uidata.applicantBank.toLowerCase()+".com", "two" : "admin@"+uidata.advisingBankID.toLowerCase()+".com", "three" : uidata.beneficiaryId.toLowerCase()+"@mail.com"}; 
				//   to.one = uidata.applicantBank.toLowerCase()+"@mail.com";
				//	to.two = uidata.advisingBankID.toLowerCase()+"@mail.com";
				//	to.three = uidata.beneficiaryId.toLowerCase()+"@mail.com";
				var stat = "Requesting for LC Status - requested";
				var msg = "Hi,\n I have requested for LC. Kindly process. "+uidata.lcReqId+" is requested";

                              sendEmail(fromId, to, stat, msg);
					//console.log('Last record insert id:', res.lcid);

									var response = postresang.end(uidata.lcReqId+" has been Requested successfully");
									return response;


	});
});


betabank.post('/bg-req', function(postreqang, postresang) {
	 var inf = postreqang.body;
	 ////console.log("TEXT FROM UI",inf);
			var uidata = inf;
					  ////console.log("chaincode in uidata===>",uidata);

					var record= [{
						 "bgReqID":uidata.bgReqID,
						 "guaranteeReference":uidata.guaranteeReference,
						 "customerReference":uidata.customerReference,
						 "applicantCustomer":uidata.applicantCustomer,
						 "applicantCustomerAddress":uidata.applicantCustomerAddress,
						 "currency":uidata.currency,
						 "principalAmount":uidata.principalAmount,
						 "beneficiaryBankAddress":uidata.beneficiaryBankAddress,
						 "beneficiaryBank":uidata.beneficiaryBank,
						 "applicantBank":uidata.applicantBank,
						 "applicantBankAddress":uidata.applicantBankAddress,
						 "dealDate":uidata.dealDate,
						 "valueDate":uidata.valueDate,
						 "expiryDate":uidata.expiryDate,
						 "maturityDate":uidata.maturityDate,
						 "beneficiary":uidata.beneficiary,
						 "beneficiaryAddress":uidata.beneficiaryAddress,
						 "termsAndConditions":uidata.termsAndConditions,
						 "ibanNumber":uidata.ibanNumber,
						 "furtherIdentification":uidata.furtherIdentification,
						 "detailsOfGuarantee1":uidata.detailsOfGuarantee1,
						 "applicableRule":uidata.applicableRule,
						 "senderToReceiverInformation":uidata.senderToReceiverInformation,
						 "narrative":uidata.narrative,
						 "status" : "requested",

					}];

					// //console.log("chaincode in invoke===>",chaincode);

				 beneficiarybank.query('INSERT INTO bankguarantee SET ?', record, function(err,res){
					 ////console.log("response in bg>>>>>>>>>>>>>>>>>>>",res);
				if(err) throw err;
				var fromId = uidata.applicantCustomer.toLowerCase()+"@mail.com";
			    var to = {"one":"admin@"+uidata.applicantBank.toLowerCase()+".com", "two" : "admin@"+uidata.applicantBank.toLowerCase()+".com", "three" : uidata.beneficiary.toLowerCase()+"@mail.com"}; 
				//   to.one = uidata.applicantBank.toLowerCase()+"@mail.com";
				//	to.two = uidata.advisingBankID.toLowerCase()+"@mail.com";
				//	to.three = uidata.beneficiaryId.toLowerCase()+"@mail.com";
				var stat = "Requesting for BG Status - requested";
				var msg = "Hi,\n I have requested for Bank Guarantee for"|uidata.bgReqID +"\n Kindly process. ";

                              sendEmail(fromId, to, stat, msg);
				//	//console.log('Last record insert id:', res.bgID);

									var response = postresang.end(uidata.bgReqID+" has been Requested successfully ");
									return response;


	});
});

betabank.get('/lcreq',function (req, res) {
			var queryString = "SELECT * FROM letterofcredit where status='requested' ";
		//console.log(queryString);

		beneficiarybank.getConnection(function(err, connection) {
		if (err) {
            //connection.release();
            res.json({ "code": 100, "status": "Error in connection database" });
            return;
        }
		connection.query(queryString, function(err, rows, fields) {
			if (err){
				res.send("FAILURE");
			}
			//console.log("Login Customer ",rows);
			connection.release();
			if(rows.length <=0){
				res.send(" [ { Result: 'Failure' } ]");
				return;

			}
			else{
				res.send(rows);
				return
			}


			//connection.release();
		});
	});

});
///displaying all requested records of bankguarantee
betabank.get('/bg-req',function (req, res) {
			var queryString = "SELECT * FROM bankguarantee where status='requested' ";
		console.log(queryString);

		beneficiarybank.getConnection(function(err, connection) {
		if (err) {
            //connection.release();
            res.json({ "code": 100, "status": "Error in connection database" });
            return;
        }
			connection.query(queryString, function(err, rows, fields) {
			if (err){
				res.send("FAILURE");
			}
			//console.log("Login Customer ",rows);
			connection.release();
			if(rows.length <=0){
				res.send(" [ { Result: 'Failure' } ]");
				return;

			}
			else{
				res.send(rows);
				return
			}


			//connection.release();
		});
	});

});

//for individual req
betabank.get('/lcreq/:LCReqNumb', function(req, res) {
	var param = req.params.LCReqNumb;

	var queryString ='select * from letterofcredit where lcreqid=?';
	//console.log(queryString);

	beneficiarybank.getConnection(function(err, connection) {
		if (err) {
            //connection.release();
            res.json({ "code": 100, "status": "Error in connection database" });
            return;
        }
		connection.query(queryString, [param], function(err, rows, fields) {
			if (err) {
				res.send("FAILURE");
			}
			//console.log("requested LC ", rows);
			connection.release();
			if (rows.length <= 0) {
				res.send(" [ { Result: 'Failure' } ]");
				return;
			} else {
				res.send(rows);
				return
			}

			//connection.release();
		});

	});


});
//for individual bankguarantee req
betabank.get('/bg-req/:BGReqNumb', function(req, res) {
	var param = req.params.BGReqNumb;

	var queryString ='select * from bankguarantee where bgReqID=?';
	////console.log(queryString);

	beneficiarybank.getConnection(function(err, connection) {
		if (err) {
            //connection.release();
            res.json({ "code": 100, "status": "Error in connection database" });
            return;
        }
		connection.query(queryString, [param], function(err, rows, fields) {
			if (err) {
				res.send("FAILURE");
			}
			////console.log("requested LC ", rows);
			connection.release();
			if (rows.length <= 0) {
				res.send(" [ { Result: 'Failure' } ]");
				return;
			} else {
				res.send(rows);
				return
			}

			//connection.release();
		});

	});


});








betabank.get('/get-customer-lc/:name', function (req, res) {
	var param=req.params.name;


		var queryString = "select * from letterofcredit where status='requested' and applicantcustomer=?";
		//console.log(queryString);

		beneficiarybank.getConnection(function(err, connection) {
		if (err) {
            //connection.release();
            res.json({ "code": 100, "status": "Error in connection database" });
            return;
        }
			connection.query(queryString,[param], function(err, rows, fields) {
			if (err){
				res.send("FAILURE");
			}
			////console.log("LC VALUES ",rows);
			connection.release();
			if(rows.length <=0){
				res.send(" [ { Result: 'Failure' } ]");
				return;

			}
			else{
				res.send(rows);
				return
			}


			//connection.release();
		});
	});

});


//get customer bank Guarantee
betabank.get('/get-customer-bg/:name', function (req, res) {
	var param=req.params.name;
		var queryString = "select * from bankguarantee where status='requested' and applicantcustomer=?";
		////console.log(queryString);

		beneficiarybank.getConnection(function(err, connection) {
		if (err) {
            //connection.release();
            res.json({ "code": 100, "status": "Error in connection database" });
            return;
        }
			connection.query(queryString,[param], function(err, rows, fields) {
			if (err){
				res.send("FAILURE");
			}
			////console.log("LC VALUES ",rows);
			connection.release();
			if(rows.length <=0){
				res.send(" [ { Result: 'Failure' } ]");
				return;

			}
			else{
				res.send(rows);
				return
			}
			//connection.release();
		});
	});

});
//lc-amend-req/{lcAmendId}"


betabank.get('/lc-amend-req/:lcAmendId', function (req, res) {
var param=req.params.lcAmendId;

var queryString = "select * from letterofcreditamend WHERE lcAmendId=? and status='AmendRequested'";
//console.log(queryString);

beneficiarybank.getConnection(function(err, connection) {
	if (err) {
            //connection.release();
            res.json({ "code": 100, "status": "Error in connection database" });
            return;
    }
			connection.query(queryString,[param], function(err, rows, fields) {
			if (err){
				res.send("FAILURE");
			}
			//console.log("LC VALUES ",rows);
			connection.release();
			if(rows.length <=0){
				//console.log("err ",err);
				res.send("FAILURE");
				return;

			}

			else{
				res.send(rows);
				return
			}


			//connection.release();
		});
	});







});

betabank.get('/bg-amend-req/:bgAmendId', function (req, res) {
var param=req.params.bgAmendId;

var queryString = "select * from bankguaranteeamend WHERE bgAmendId=? and status='AMEND REQUESTED'";
//console.log(queryString);

beneficiarybank.getConnection(function(err, connection) {
	if (err) {
            //connection.release();
            res.json({ "code": 100, "status": "Error in connection database" });
            return;
        }
			connection.query(queryString,[param], function(err, rows, fields) {
			if (err){
				res.send("FAILURE");
			}
			//console.log("LC VALUES ",rows);
			connection.release();
			if(rows.length <=0){
				console.log("err ",err);
				res.send("FAILURE");
				return;

			}

			else{
				res.send(rows);
				return
			}


			//connection.release();
		});
	});
});



betabank.post('/bg-amend-approve', function(req, res) {
	var bog = req.body;
	var ID = bog.bgId;
var status1 = bog.status;
var BGREQ = bog.bgReqID;
console.log("@@@@@@@@@@@@@@@@@@@@@@@AMEND_APPROVED@@@@@@@@@@@@@@@@@@@@@@@@@@@@",req,status1);




	/*  applicantBank.query("UPDATE letterofcreditamend SET status ='AMEND_APPROVED' WHERE lcreqid = ?", [LCREQ], function(err, result){
							 if(err) throw err;
							 //console.log('updated of record:', result);
			}); */




	var input  = JSON.stringify(bog);
chaincode.invoke.BGApprove([ID, status1]);
	var response = res.end(ID+" has been Amend-approved successfully");


				var fromId = bog.applicantCustomer.toLowerCase()+"@mail.com";
			    var to = {"one":"admin@"+bog.applicantBank.toLowerCase()+".com", "two" : "admin@"+bog.applicantBank.toLowerCase()+".com", "three" : bog.beneficiary.toLowerCase()+"@mail.com"}; 
				var stat = "Requesting for BG Status - Amend Approved";
				var msg = "Hi,\n I have approved the amendment for BG"+bog.bgReqID;

                              sendEmail(fromId, to, stat, msg);

	return response;
});




betabank.post('/lc-amend-approve', function(req, res) {
	var loc = req.body;
	var ID = loc.lcId;
var status1 = loc.status;
var LCREQ = loc.lcReqId;
//console.log("@@@@@@@@@@@@@@@@@@@@@@@AMEND_APPROVED@@@@@@@@@@@@@@@@@@@@@@@@@@@@",status1);




	/*  applicantBank.query("UPDATE letterofcreditamend SET status ='AMEND_APPROVED' WHERE lcreqid = ?", [LCREQ], function(err, result){
							 if(err) throw err;
							 //console.log('updated of record:', result);
			}); */




	var input  = JSON.stringify(loc);
chaincode.invoke.UpdateStatus([ID, status1]);
	var response = res.end(ID+" has been Amend-approved successfully");


				var fromId = "admin@"+loc.advisingBankID.toLowerCase()+".com";
			    var to = {"one":loc.applicantCustomer.toLowerCase()+"@mail.com", "two" : "admin@"+loc.applicantBank.toLowerCase()+".com", "three" : loc.beneficiaryId.toLowerCase()+"@mail.com"}; 
				var stat = "Requesting for LC Status - Amend Approved";
				var msg = "Hi,\n I have approved the amendment for LC"+loc.lcReqId;

                              sendEmail(fromId, to, stat, msg);

	return response;
});

//Bill
betabank.post('/lc-docs-verify/:lcId', function(req, res) {

//console.log("inside verify js file betabank=========================>>>>>>>>>>")

var indexLc=req.params.lcId;
//var lcRec = req.body;
//console.log(" index -     - ",indexLc);
////console.log(" lcRec -     - ",lcRec);
//var input  = JSON.stringify(lcRec);
chaincode.invoke.VerifyBill([indexLc]);
var response = res.end("Verified Bill");
return response;

});


betabank.post('/lodge-bill/:lcId', function(req, res) {

//console.log("inside bill lodge in js file=========================>>>>>>>>>>")

var indexLc=req.params.lcId;
	var bill = req.body;
//console.log(" index -     - ",indexLc);
//console.log(" Bill -     - ",bill);
var billAmount = bill.bills[0].billAmount;
var billNo=bill.bills[0].billNo;

var billLength = bill.bills.length;
//console.log("length of bills=====>>>>>>>",billLength);


//console.log("****** Bill No     - ",billNo);
//console.log("Bill Amount - ",billAmount);
var input  = JSON.stringify(bill.bills[billLength-1]);
//console.log("json",input);
chaincode.invoke.LodgeBill([indexLc, input]);

var response = res.end(billNo + " has been Generated for " +indexLc);
return response;
//var response = postresang.end(uidata.lcAmendReqId+" has been Requested successfully");
//var response = res.end("Created successfully");



});


                function sendEmail(fromId, toId, subject, message) {
					currentToId = toId;
					//console.log('currentToId first', currentToId);
					//console.log('toId first', toId);
					if(currentToId.one)
					{
						toId = currentToId.one;
					}
					if(currentToId.one)
					{
						toId += ","+currentToId.two;
					}
					if(currentToId.one)
					{
						toId += ","+currentToId.three;
					}
					//console.log('currentToId : %s \n toId: %s', currentToId, toId);

                                var mailOptions = {
                                                from: fromId, // sender address
                                                to: toId, // list of receivers
                                                subject: subject, // Subject line
                                                text: message //, // plaintext body
                                                // html: '<b>Hello world ✔</b>' // You can choose to send an HTML body instead
                                };

                                transporter.sendMail(mailOptions, (error, info) => {
                                                if (error) {
                                                                return //console.log(error);
                                                }
                                                //console.log('Message %s sent: %s', info.messageId, info.response);
                                });

                                return null;
    }




								betabank.post('/email-for-amend', function(postreqang, postresang) {
																var email = postreqang.body;
															//  var x = sendEmail("a@a.com", "b@b.com", "t1","message");


																var mailOptions = {
																								from: email.from, // sender address
																								to: email.to, // list of receivers
																								subject: email.subject, // Subject line
																								text: email.msg //, // plaintext body
																								// html: '<b>Hello world ✔</b>' // You can choose to send an HTML body instead
																};
																//console.log(" send sendMail",mailOptions);

																transporter.sendMail(mailOptions, (error, info) => {
																								if (error) {
																																return //console.log(error);
																								}
																								//console.log('Message %s sent: %s', info.messageId, info.response);
																});

																postresang.send("An email for Amendment is sent");
								});



var beta = betabank.listen(10007, function() {


});
var host = beta.address().address
var port1 = beta.address().port
//console.log("BETA BANK listening at http://%s:%s", host, port1)
