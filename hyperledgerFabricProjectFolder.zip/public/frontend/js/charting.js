
        
          function showhide() {
		  
		  myFunction();
		  
		  
				var e1 = document.getElementById('chart');

				var e2 = document.getElementById('uniquename');

				if(e1.style.display == '' )
				{
					e1.style.display = 'none';
					e2.style.display=''
				}
				else
				{
					e2.style.display='none'
					e1.style.display=''
				}
				
				
     	}
		 
		 
         function freedoughnutgraph(percent)
         {
         	
         	//('#chart').find('svg').first().remove();
			
         	
         	var list = document.getElementsByClassName("shadow");
         	 for(var i = list.length - 1; 0 <= i; i--)
         	 	{
         		 	if(list[i] && list[i].parentElement)
         			 list[i].parentElement.removeChild(list[i]);
         		}
         	 
         	
         	 var ratio=percent/100;
         
             var pie=d3.layout.pie()
                     .value(function(d){return d})
                     .sort(null);
         
             var w=300,h=300;
         
             var outerRadius=(w/2)-10;
             var innerRadius=85;
         
         if (percent < 30)
         {
             var color = ['#ececec','#FB0606','#888888'];
         }
         else if (percent < 60)
         {
         	
         	var color = ['#ececec','#2106FB','#888888'];
         }
         else
         {
         	var color = ['#ececec','#06FB14','#888888'];
         }
         
             var colorOld='#F00';
             var colorNew='#0F0';
         
             var arc=d3.svg.arc()
                     .innerRadius(innerRadius)
                     .outerRadius(outerRadius)
                     .startAngle(0)
                     .endAngle(Math.PI);
         
         
             var arcLine=d3.svg.arc()
                     .innerRadius(innerRadius)
                     .outerRadius(outerRadius)
                     .startAngle(0);
         
             var svg=d3.select("#chart")
                     .append("svg")
                     .attr({
                         width:w,
                         height:h,
                         class:'shadow'
                     }).append('g')
                     .attr({
                         transform:'translate('+w/2+','+h/2+')'
                     });
         
             var path=svg.append('path')
                     .attr({
                         d:arc,
                         transform:'rotate(-90)'
                     }).attr({
                         'stroke-width':"1",
                         stroke:"#666666"
                     })
                     .style({
                         fill:color[0]
                     });
         
         
             var pathForeground=svg.append('path')
                     .datum({endAngle:0})
                     .attr({
                         d:arcLine,
                         transform:'rotate(-90)'
                     })
                     .style({
                         fill: function (d,i) {
                             return color[1];
                         }
                     });
         
         
             var middleCount=svg.append('text')
                     .datum(0)
                     .text(function(d){
                         return d;
                     })
                     .attr({
                         class:'middleText',
                         'text-anchor':'middle',
                         dy:0,
                         dx:5
                     })
                     .style({
                         fill:d3.rgb('#000000'),
                         'font-size':'15px'
         
         
         
                     });
         
             var oldValue=0;
             var arcTween=function(transition, newValue,oldValue) {
                 transition.attrTween("d", function (d) {
                     var interpolate = d3.interpolate(d.endAngle, ((Math.PI))*(newValue/100));
         
                     //var interpolateCount = d3.interpolate(oldValue, newValue);
         			//var interpolateCount = "Account number";
         
                     return function (t) {
                         d.endAngle = interpolate(t);
                        // middleCount.text(Math.floor(interpolateCount(t))+'%');
         			   middleCount.text('A/c No:50100234543', '');
         
                         return arcLine(d);
                     };
                 });
             };
         
         
             pathForeground.transition()
                     .duration(750)
                     .ease('cubic')
                     .call(arcTween,percent,oldValue);
         			
         	
         }
         
         
         
            
         			
         function myFunction() {
             var txt;
			 var amt=25000;
			 var n=50;
             var value1 = document.getElementById("val1").value;
         	 var value2 = document.getElementById("val2").value;
			
			
			if(value1<amt && value2>amt)
			{
			//alert('Your Account balance amount is below the Maximum limit !!!!');
			n=40;
			}
			
			else if(value2<amt)
			{
			//alert('Your Account balance amount is above the Maximum limit !!!!');
			n=70;
			}
			else if(value1>amt)
			{
			//alert('Your Account balance amount is below the mininmum limit !!!!');
			n=25;
			}
			
			
           //console.log("nnnnnnnnnnnnn "+n);
		   
		   document.getElementById("val1").value=="";
			 document.getElementById("val2").value=="";
         	
             freedoughnutgraph(n);
			 
         }
         
         
         function checkTime(i) {
  		 if (i < 10) {
  		  i = "0" + i;
 			 }
 			 return i;
			}

		function startTime() {
		var today = new Date();
		var dd = today.getDate();
		var mm = today.getMonth()+1; 
		var yyyy = today.getFullYear();

		if(dd<10) {
   		 dd = '0'+dd
				} 

		if(mm<10) {
   		 mm = '0'+mm
		} 

  		var h = today.getHours();
  		var m = today.getMinutes();
  		var s = today.getSeconds();
  		// add a zero in front of numbers<10
 		 m = checkTime(m);
 		 s = checkTime(s);
 		 document.getElementById('time').innerHTML = mm + '/' + dd + '/' + yyyy +" "+ h + ":" + m + ":" + s;
 		 t = setTimeout(function() {
  		  startTime()
 		 }, 500);
		}
         
         
         
      