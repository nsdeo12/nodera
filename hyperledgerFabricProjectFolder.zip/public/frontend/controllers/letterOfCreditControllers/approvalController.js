app.controller('approvalController', function($http,$uibModal, $location,$rootScope, $scope, $cookies,$cookieStore,shareid) {
  if($cookieStore.get('employee')){
                    $scope.message = 'Approve Letter of Credits ';
                    $scope.node = shareid.thisNode;
                     $scope.username = $cookieStore.get('employee');
					 const nodePort = $location.port();
					  const apiBaseURL = "http://"+window.__env.apiUrl+":" + nodePort + "";
                     console.log("APPROVING ID ===>",shareid.lcApproveID,"  node is ",$scope.node," username is ",$scope.username);
                     const LCReqNumb = $rootScope.ID;

                        $scope.logout = function(){
                        $cookieStore.remove('employee');
                        $location.path("/customer");
                            };
                        $scope.lcApproveForm = {};
                        $scope.formError = false;

                    //const LCApprovalId = $rootScope.ApproveID;
					const LCApprovalId=shareid.lcApproveID;
                   // const apiBaseURL = $rootScope.apiBaseURL;
                    //const getObj = apiBaseURL + "lc-orders";
                    const cusID1 = $cookieStore.get('employee');
                    const getObj = apiBaseURL + "/employee-lc-orders/"+LCApprovalId;

                    $http.get(getObj).then(function(response){
                    var finalData = response.data;
                    console.log("RESPONSE DATA ", finalData);
                    console.log("RESPONSE DATA final", finalData.DATA);
                    $scope.lcRequestID = finalData.DATA.lcReqId;

                      $scope.lcApproveForm.lcId = finalData.DATA.lcId;
                      $scope.lcApproveForm.applicant = finalData.DATA.applicantCustomer;
                      $scope.lcApproveForm.applicantaddress = finalData.DATA.applicantAddress;
                      //$scope.lcApproveForm.shipmentperiod =  finalData[0].lcorder.shipmentPeriod;
                      $scope.lcApproveForm.lcexpirydate = finalData.DATA.lcExpiryDate;
                      $scope.lcApproveForm.modeofshipment =  finalData.DATA.modeOfShipment;
                      $scope.lcApproveForm.beneficiary = finalData.DATA.beneficiaryId;
                      $scope.lcApproveForm.beneficiaryaddress = finalData.DATA.beneficiaryAddress;
                      $scope.lcApproveForm.lctype = finalData.DATA.lcType;
                      $scope.lcApproveForm.lccurrency = finalData.DATA.lcCurrency;
                      $scope.lcApproveForm.lcamount =  finalData.DATA.lcAmount;
                      $scope.lcApproveForm.lcissuedate = finalData.DATA.lcIssueDate;
                      $scope.lcApproveForm.lcexpiryplace = finalData.DATA.lcExpiryPlace;
                      $scope.lcApproveForm.shipmentdate = finalData.DATA.latestShipmentDate;
                      $scope.lcApproveForm.liabilitydate = finalData.DATA.liabilityReversalDate;
                      $scope.lcApproveForm.beneficiarybank = finalData.DATA.advisingBankID;
                      $scope.lcApproveForm.applicantBank = finalData.DATA.applicantBank;
                      $scope.lcApproveForm.applicantBankAddress = finalData.DATA.applicantBankAddress;
                      $scope.lcApproveForm.beneficiarybankaddress = finalData.DATA.advisingBankAddress;
                      $scope.lcApproveForm.DocumentaryCredit = finalData.DATA.formofDocumentaryCredit;
                      $scope.lcApproveForm.CreditNumber = finalData.DATA.documentaryCreditNumber;
                      $scope.lcApproveForm.AvailableWith = finalData.DATA.availableWithBy;
                      $scope.lcApproveForm.TransportationTo = finalData.DATA.forTransportationTo;
                      $scope.lcApproveForm.DescOfGoods = finalData.DATA.descriptionOfGoodsAndOrServices;
                      $scope.lcApproveForm.additionalConditions = finalData.DATA.additionalConditions;
                      $scope.lcApproveForm.PeriodForPresentaion = finalData.DATA.periodForPresentation;
                      $scope.lcApproveForm.AdvisingThroughBank = finalData.DATA.advisingThroughBank;
                      $scope.lcApproveForm.transhipment = finalData.DATA.transshipment;
                      $scope.lcApproveForm.PortofLoading = finalData.DATA.portofLoading;
                      $scope.lcApproveForm.MaxCreditAmount = finalData.DATA.maximumCreditAmount;
                      $scope.lcApproveForm.DraftsAt = finalData.DATA.draftsAt;
                      $scope.lcApproveForm.PartialShipments = finalData.DATA.partialShipments;
                      $scope.lcApproveForm.SenderToReceiverInfo = finalData.DATA.senderToReceiverInformation;
                      $scope.lcApproveForm.Charges = finalData.DATA.charges;
                      $scope.lcApproveForm.ConfirmationInstruction = finalData.DATA.confirmationInstructions;
                      $scope.lcApproveForm.SequenceTotal = finalData.DATA.sequenceOfTotal;
                      $scope.lcApproveForm.DocRequired = finalData.DATA.documentsRequired;
                      $scope.lcApproveForm.iban = finalData.DATA.ibanNumber;
                      $scope.lcApproveForm.incoTerms=finalData.DATA.incoTerms;

                      //New Changes:24-03-2017 : Deepak:Begin
                                 $scope.lcApproveForm.DraftsAt_sight=	finalData.DATA.draftsAtSight;
                                 $scope.lcApproveForm.DraftsAt_usance=	finalData.DATA.draftsAtUsance;
                                 $scope.lcApproveForm.shipmentperiod_sight=	finalData.DATA.shipmentPeriodSight;
                                 $scope.lcApproveForm.shipmentperiod_usance=	finalData.DATA.shipmentPeriodUsance;
                                 $scope.lcApproveForm.Percentage_sight=	finalData.DATA.percentageSight;
                                 $scope.lcApproveForm.Percentage_usance=	finalData.DATA.percentageUsance;
                                 $scope.lcApproveForm.lcamount_sight=	finalData.DATA.lcAmountSight;
                                 $scope.lcApproveForm.lcamount_usance=	finalData.DATA.lcAmountUsance;
                        //New Changes:24-03-2017 : Deepak:END
                        });


                    $scope.approveLC = () => {

                    const approveLOC = {
                          lcId : $scope.lcApproveForm.lcId,
                          lcReqId : $scope.lcRequestID,
                          applicantCustomer : $scope.lcApproveForm.applicant,
                          applicantAddress : $scope.lcApproveForm.applicantaddress,
                          //shipmentPeriod : $scope.lcApproveForm.shipmentperiod,
                          lcExpiryDate : $scope.lcApproveForm.lcexpirydate,
                          modeOfShipment : $scope.lcApproveForm.modeofshipment,
                          beneficiaryId : $scope.lcApproveForm.beneficiary,
                          beneficiaryAddress : $scope.lcApproveForm.beneficiaryaddress,
                          lcType : $scope.lcApproveForm.lctype,
                          lcCurrency : $scope.lcApproveForm.lccurrency,
                          lcAmount : $scope.lcApproveForm.lcamount,
                          lcIssueDate : $scope.lcApproveForm.lcissuedate,
                          lcExpiryPlace : $scope.lcApproveForm.lcexpiryplace,
                          latestShipmentDate : $scope.lcApproveForm.shipmentdate,
                          liabilityReversalDate : $scope.lcApproveForm.liabilitydate,
                          advisingBankID : $scope.lcApproveForm.beneficiarybank,
                          applicantBank : $scope.lcApproveForm.applicantBank,
                          applicantBankAddress : $scope.lcApproveForm.applicantBankAddress,
                          advisingBankAddress : $scope.lcApproveForm.beneficiarybankaddress,
                          formofDocumentaryCredit : $scope.lcApproveForm.DocumentaryCredit,
                          documentaryCreditNumber : $scope.lcApproveForm.CreditNumber,
                          availableWithBy : $scope.lcApproveForm.AvailableWith,
                          forTransportationTo : $scope.lcApproveForm.TransportationTo,
                          descriptionOfGoodsAndOrServices : $scope.lcApproveForm.DescOfGoods,
                          additionalConditions : $scope.lcApproveForm.additionalConditions,
                          periodForPresentation : $scope.lcApproveForm.PeriodForPresentaion,
                          advisingThroughBank : $scope.lcApproveForm.AdvisingThroughBank,
                          transshipment : $scope.lcApproveForm.transhipment,
                          portofLoading : $scope.lcApproveForm.PortofLoading,
                          maximumCreditAmount : $scope.lcApproveForm.MaxCreditAmount,
                          draftsAt : $scope.lcApproveForm.DraftsAt,
                          partialShipments : $scope.lcApproveForm.PartialShipments,
                          senderToReceiverInformation : $scope.lcApproveForm.SenderToReceiverInfo,
                          charges : $scope.lcApproveForm.Charges,
                          confirmationInstructions : $scope.lcApproveForm.ConfirmationInstruction,
                          sequenceOfTotal : $scope.lcApproveForm.SequenceTotal,
                          //documentsRequired : docrec1,
                          ibanNumber : $scope.lcApproveForm.iban,
                          incoTerms:$scope.lcApproveForm.incoTerms,

                            //New Changes:24-03-2017 : Deepak:Begin

                              draftsAtSight : $scope.lcApproveForm.DraftsAt_sight,
                                draftsAtUsance: $scope.lcApproveForm.DraftsAt_usance,
                                shipmentPeriodSight: $scope.lcApproveForm.shipmentperiod_sight,
                                 shipmentPeriodUsance:$scope.lcApproveForm.shipmentperiod_usance,
                                percentageSight: $scope.lcApproveForm.Percentage_sight,
                                percentageUsance: $scope.lcApproveForm.Percentage_usance,
                                 lcAmountSight:$scope.lcApproveForm.lcamount_sight,
                                 lcAmountUsance:$scope.lcApproveForm.lcamount_usance,

                            //New Changes:24-03-2017 : Deepak:END

                          documentsRequired: $scope.lcApproveForm.DocRequired,
                          status : "APPROVED"
				
                                };
                                    const approveLCEndpoint =
                                        apiBaseURL +"/lc-approve";

console.log("approve LOC object  ",approveLOC);
                                   $http.post(approveLCEndpoint, angular.toJson(approveLOC)).then(
                                   function(result){
                                    // success callback
                                    console.log("INSIDE SUCCESS FUNCTION");
									 shareid.tab=2;
                                    $location.path("/employeeHome");
                                    displayMessage(result);
                                    }, 
                                    function(result){
                                    // failure callback
                                    console.log("INSIDE ERROR FUNCTION");
                                    displayMessage(result);
                                                                         }
                                        //(result) => displayMessage(result),
                                        //(result) => displayMessage(result)
                                    );
                                    // console.log("LC approved and the object is  ",approveLoc);
                                     //console.log("message status" , $scope.messageStatus);
                                     //$location.path("/home");
                        }
                        $scope.cancel = () => {
							shareid.tab=2;
                              $location.path("/employeeHome");
                        }
                        displayMessage = (message) => {
                        console.log("message in display message--->",message);
                        $rootScope.messageStatus = message.status;
                                const modalInstanceTwo = $uibModal.open({
                                    templateUrl: 'messageContent.html',
                                    controller: 'messageCtrl',
                                    controllerAs: 'modalInstanceTwo',
                                    resolve: { message: () => message }
                                });

                                modalInstanceTwo.result.then(() => {}, () => {});
                            };

                        function invalidFormInput() {
                            const invalidNonItemFields = !$scope.lcform.lcrequest
                    //            || isNaN(modalInstance.form.orderNumber)
                    //            || !modalInstance.form.deliveryDate
                    //            || !modalInstance.form.city
                    //            || !modalInstance.form.country;
                    //
                    //        const inValidCounterparty = modalInstance.form.counterparty === undefined;
                    //
                    //        const invalidItemFields = modalInstance.items
                    //            .map(item => !item.name || !item.amount || isNaN(item.amount))
                    //            .reduce((prev, curr) => prev && curr);

                            return invalidNonItemFields;
                        }
                        }
                                                else{
                                                $location.path("/customer");
                                                }

                  });
/*==========================================================================================================================
                     ****************Code for LC Amendment Request************************
                     ****************Developer name : Kesavan N B
                      *****************Start************************/