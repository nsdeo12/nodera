   app.controller('requestController', function($http,$uibModal, $location,$rootScope, $scope,$cookies,$cookieStore,rootValues,shareidCustomer) {
         if($cookieStore.get('customer')){
			 $scope.selectedIndex = 2;

//tabbed request page starts////////////////////////////////////////////////////
$scope.tabs = [{
           title: 'Import LC Basic Info',
           url: 'one.tpl.html',
		   test: 'lcRequestTab1.html'
       }, {
           title: 'Parties to LC',
           url: 'two.tpl.html'
       }, {
           title: 'Charges',
           url: 'three.tpl.html'
   },{
       title: 'Commission',
       url: 'four.tpl.html'
},
{
    title: 'Syndication',
    url: 'five.tpl.html'
},
{
    title: 'Margin Details',
    url: 'six.tpl.html'
},
{
    title: 'Pay/Revolving Details',
    url: 'seven.tpl.html'
},
{
    title: 'Documents and conditions',
    url: 'eight.tpl.html'
},
{
    title: 'MT 700/701',
    url: 'nine.tpl.html'
},
{
    title: 'Messages',
    url: 'ten.tpl.html'
}];

   $scope.currentTab = 'one.tpl.html';

   $scope.onClickTab = function (tab) {
       $scope.currentTab = tab.url;
   }

   $scope.isActiveTab = function(tabUrl) {
       return tabUrl == $scope.currentTab;
   }

//tabbed request page ends//////////////////////////////////////////////////////



                          $scope.message = 'Request Letter of Credit';
						     const nodePort = $location.port();
                         const apiBaseURL = "http://"+window.__env.apiUrl+":" + nodePort + "";
						 // const apiBaseURL = $rootScope.apiBaseURL;
                        //  const LCRequestId = $rootScope.lcRequestID;

                         $scope.id = rootValues.data1;
                        console.log("rootID",$scope.id);


						  // const LCRequestId = '123342';
              const LCRequestId=rootValues.id;
						 // $rootScope.ID12=LCRequestId;

						  //  console.log("LCRequestId222:",LCRequestId);
							  console.log("$rootScope.ID:",LCRequestId);
						 // const LCRequestId = $rootScope.lcRequestID;
                          $scope.node = $rootScope.thisNode;
                          console.log("apiBaseNil:",apiBaseURL);



                          $scope.logout = function(){
                          $cookieStore.remove('customer');
                          $location.path("/customer");
                                };
                          const requestID = "LC-REQ-"+$scope.id;
                          //const requestID = "LC-REQ-"+LCRequestId;
						  console.log("1",LCRequestId);
						  console.log("2",requestID);
                            $scope.username = $cookieStore.get('customer');
                            $http.get(apiBaseURL + "/customer/detail/id/"+ $scope.username).then(function(response){
								console.log('respp',response.data[0]);
                                                  $scope.lcForm.lcissuedate = new Date();
                                                  $scope.lcForm.lcReqNo  = requestID;
                                                  $scope.lcForm.applicant  = response.data[0].name;
                                                  $scope.lcForm.applicantaddress  = response.data[0].customeraddress;
                                                  $scope.lcForm.applicantBank = response.data[0].bank;
                                                  $scope.lcForm.applicantBankAddress = response.data[0].bankaddress;
                                                 });



                        $http.get(apiBaseURL + "/othercustomer").then(function(response){
                                                $scope.cusList = [];
                                                    const otherCustomer = response;
													console.log('otherCustomer',otherCustomer);
                                               for(var j=0; j<otherCustomer.data.length; j++){
												   console.log('otherCustomerLoop',otherCustomer.data[j]);
                                                   $scope.cusList.push(otherCustomer.data[j].ibanno);
                                                };


                                 });

                        //Amount Test

                        /*$s
                        $scope.AmountChange = function() {
                                    const amountValue = $scope.lcForm.amount;
                                     };*/
                        //end


                         $scope.ibanChange = function() {
                        const ibanValue = $scope.lcForm.iban;
                        $http.get(apiBaseURL + "/customer/detail/"+ ibanValue).then(function(response){
                                                  $scope.lcForm.beneficiary  = response.data[0].name;
                                                  $scope.lcForm.beneficiaryaddress  = response.data[0].customeraddress;
                                                  $scope.lcForm.beneficiarybank  = response.data[0].bank;
                                                  $scope.lcForm.beneficiarybankaddress  = response.data[0].bankaddress;
                                 });
                         };

                              $scope.lcForm = {};
                              $scope.formError = false;
                              $scope.isCollapsed = true;

                              $scope.lcForm.DraftsAt='SIGHT';                                
                              $scope.lctype=['SELECT','SIGHT','USANCE','MIXED'];

                           	  //$scope.lctype=['SIGHT','USANCE','MIXED'];
                           	  $scope.incoTerms = ['CFR-Cost and freight','CIF-Cost,Insurance and freight','CIP-Carriage and Insurance paid to','CPT-Carriage paid to','DAF-Delivered at Frontier','DAP-Delivered at place','DAT-Delivered at terminal',
                           	                        'DDP-Delivered duty paid','DDU-Delivered duty unpaid','DEQ-Delivered Ex Quay','DES-Delivered Ex ship','EXW-Ex Works','FAS-Free Alongside Ship','FCA-Free carrier','FOB-Free on board'];


                               $scope.percent1 = () =>{
                               console.log("percent1")
                               var per=$scope.lcForm.Percentage_sight;
                               var amt=$scope.lcForm.lcamount;
                               var res=amt*per/100;
                               var res1=amt*(100-per)/100;
                               console.log(res);
                               $scope.lcForm.lcamount_sight=res;

                               $scope.lcForm.Percentage_usance=100-$scope.lcForm.Percentage_sight;
                               $scope.lcForm.lcamount_usance=res1;

                               }

                                $scope.percent2 = () =>{
                                  console.log("percent2")
                                var per2=$scope.lcForm.Percentage_usance;
                                var per1=100-per2;
                                var amt=$scope.lcForm.lcamount;

                                var amount2 = amt*per2/100;
                                var amount1 = amt*per1/100;
                                $scope.lcForm.lcamount_usance=amount2;
                               $scope.lcForm.lcamount_sight=amount1;
                               $scope.lcForm.Percentage_sight = per1;
                              }

                                $scope.drafts = () =>{
                                    var x =$scope.lcForm.lctype;
                                          if(x=='USANCE'){
                                           // alert("input empty");
                                               $scope.lcForm.DraftsAt_usance='';
                                               $scope.lcForm.DraftsAt_sight='USANCE';
                                               $scope.lcForm.lcamount_usance='0';
                                               $scope.lcForm.lcamount_sight='0';
                                               $scope.lcForm.shipmentperiod_sight='';
                                               $scope.lcForm.shipmentperiod_usance;
                                                $scope.lcForm.Percentage_sight='';
                                                $scope.lcForm.Percentage_usance='';
                                                 }
                                                 else if(x=='SIGHT'){
                                                    $scope.lcForm.DraftsAt_sight='SIGHT';
                                                    $scope.lcForm.DraftsAt_usance='';
                                                    $scope.lcForm.lcamount_usance='0';
                                                    $scope.lcForm.lcamount_sight='0';
                                                    $scope.lcForm.shipmentperiod_sight='';
                                                   $scope.lcForm.shipmentperiod_usance;
                                                    $scope.lcForm.Percentage_sight='';
                                                    $scope.lcForm.Percentage_usance='';


                                                 }
                                                 else if(x=='MIXED'){
                                                $scope.lcForm.DraftsAt_usance='';
                                                $scope.lcForm.DraftsAt_sight='';
                                                $scope.lcForm.Percentage_sight='';
                                                $scope.lcForm.Percentage_usance='';
                                                $scope.lcForm.lcamount_sight='';
                                                $scope.lcForm.lcamount_usance='';
                                                $scope.lcForm.shipmentperiod_sight='';
                                                $scope.lcForm.shipmentperiod_usance;
                                                $scope.lcForm.DraftsAt_sight='SIGHT';
                                                $scope.lcForm.DraftsAt_usance='USANCE';
                                                 }
                                                   else if(x=='SELECT'){
                                                $scope.lcForm.DraftsAt_usance='';
                                                $scope.lcForm.DraftsAt_sight='';
                                                $scope.lcForm.Percentage_sight='';
                                                $scope.lcForm.Percentage_usance='';
                                                $scope.lcForm.lcamount_sight='';
                                                $scope.lcForm.lcamount_usance='';
                                                $scope.lcForm.shipmentperiod_sight='';
                                                $scope.lcForm.shipmentperiod_usance;
                                                $scope.lcForm.DraftsAt_sight='';
                                                $scope.lcForm.DraftsAt_usance='';
                                                 }
                                             }



                              $scope.lccurrency = ['USD'];
							   $scope.applicableRuleCodes = ['Eucp Latest Version','Eucpurr Latest Version','Isp Latest Version','othr','Ucp Latest Version','Ucpurr Latest Version'] 
                              $scope.lcForm.lcissuedate = new Date().toLocaleDateString();


                              console.log("LCRequestId as current node",LCRequestId);

                              //chndu integration

                                                            $scope.datechange = () => {
                                                                    console.log("dateChange triggered");
                                                                    if($scope.lcForm.shipmentdate>$scope.lcForm.lcexpirydate){
                                                                           console.log("Inside date if");
                                                                           alert("Shipment Date should be less than LC Expiry Date");
                                                                           $scope.lcForm.shipmentdate =$scope.lcForm.lcissuedate;

                                                                    }
                                                            }

                                                            $scope.expirydatechange= () => {

                                                                    console.log("dateChange in Expiry date triggered");
                                                                    console.log("hi");
                                                                    console.log("LC ISSUE DATE",$scope.lcForm.lcissuedate);
                                                                    if($scope.lcForm.lcexpirydate<$scope.lcForm.lcissuedate){
                                                                         console.log("Inside date if expiry");
                                                                         alert("lcExpiry Date should not be less than lcIssueDate");
                                                                         $scope.lcForm.lcexpirydate =$scope.lcForm.lcissuedate;
                                                                    }
                                                            }
                                                       $scope.lcAmountcheck = () =>  {


							/* const createLCEndpoint1 = apiBaseURL +"/email-for-amend";

						                const mail = {
                                                fromID : "test@test.com",
                                                toID : "test@test1.com",
		                                        subject : "test",
                                                message : "Say hello"
                                        };

						 			$http.post(createLCEndpoint1, mail).then(
                                     function(result){
                                      // success callback
                                      console.log("INSIDE email  SUCCESS FUNCTION");
                                    //  $location.path("/customerHome");
                                      displayMessage(result);
                                      }, 
                                      function(result){
                                      // failure callback
                                      console.log("INSIDEemail ERROR FUNCTION");
                                      displayMessage(result);
                                      }
                                      );  */



                                                             if(($scope.lcForm.lctype == "MIXED") && ($scope.lcForm.Percentage_sight && $scope.lcForm.Percentage_usance))
                                                             {

                                                             if($scope.lcForm.Percentage_sight)
                                                             {
                                                             console.log("if $scope.lcForm.Percentage_sight", $scope.lcForm.Percentage_sight)
                                                             $scope.percent1();
                                                             }
 //                                                            if($scope.lcForm.Percentage_usance)
 //                                                            {
 //                                                            console.log("if $scope.lcForm.Percentage_usance", $scope.lcForm.Percentage_usance)
 //                                                            $scope.percent2();
 //                                                            }
                                                             }


                                                               console.log("LC AMOUNT",$scope.lcForm.lcamount);
                                                               var value = $scope.lcForm.lcamount;
                                                               //var Amtval = value.split(/(\d+)/).filter(Boolean);
                                                               var Amtval = value.split(/^([-+]?[0-9]*\.?[0-9]+)([abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ])$/);
                                                               console.log("AMT VAL  ",Amtval);

                                                               if(Amtval[2].toLowerCase()=='m'|| Amtval[2].toLowerCase()=='h'|| Amtval[2].toLowerCase()=='t'){

                                                               if(Amtval[2].toLowerCase()== "m"){
                                                               $scope.lcForm.lcamount = Amtval[1]*1000000;
                                                               }
                                                               else if(Amtval[2].toLowerCase()== "h")
                                                               {
                                                               $scope.lcForm.lcamount = Amtval[1]*100;
                                                               }
                                                               else if(Amtval[2].toLowerCase()== "t")
                                                               {
                                                               $scope.lcForm.lcamount = Amtval[1]*1000;
                                                               }
                                                               else {
                                                               $scope.lcForm.lcamount = $scope.lcForm.lcamount;
                                                               }
                                                               }
                                                               else{
                                                               console.log("inside check else");
                                                               $scope.lcForm.lcamount = "";

                                                               }

                                                             }









                              //end

                              $scope.create = () => {
                                  if (invalidFormInput()) {
                                      formError = true;
                                  } else {
                                      formError = false;

                                      const loc = {

        lcReqId : $scope.lcForm.lcReqNo,
        applicantCustomer : $scope.lcForm.applicant,
        applicantAddress : $scope.lcForm.applicantaddress,
        shipmentPeriod : $scope.lcForm.shipmentperiod,
        lcExpiryDate : new Date($scope.lcForm.lcexpirydate).toLocaleDateString(), //new Date($scope.lcForm.lcexpirydate).toLocaleDateString()
        modeOfShipment : $scope.lcForm.modeofshipment,
        beneficiaryId : $scope.lcForm.beneficiary,
        beneficiaryAddress : $scope.lcForm.beneficiaryaddress,
        lcType : $scope.lcForm.lctype,
        lcCurrency : $scope.lcForm.lccurrency,
        lcAmount : $scope.lcForm.lcamount,
        lcIssueDate : new Date($scope.lcForm.lcissuedate).toLocaleDateString(),
        lcExpiryPlace : $scope.lcForm.lcexpiryplace,
        latestShipmentDate : new Date($scope.lcForm.shipmentdate).toLocaleDateString(),
        liabilityReversalDate : new Date($scope.lcForm.liabilitydate).toLocaleDateString(),
        advisingBankID : $scope.lcForm.beneficiarybank,
        applicantBank : $scope.lcForm.applicantBank,
        applicantBankAddress : $scope.lcForm.applicantBankAddress,
        advisingBankAddress : $scope.lcForm.beneficiarybankaddress,
        formofDocumentaryCredit : $scope.lcForm.DocumentaryCredit,
        documentaryCreditNumber : $scope.lcForm.CreditNumber,
        availableWithBy : $scope.lcForm.AvailableWith,
        forTransportationTo : $scope.lcForm.TransportationTo,
        descriptionOfGoodsAndOrServices : $scope.lcForm.DescOfGoods,
        additionalConditions : $scope.lcForm.additionalConditions,
        periodForPresentation : $scope.lcForm.PeriodForPresentaion,
        advisingThroughBank : $scope.lcForm.AdvisingThroughBank,
        transshipment : $scope.lcForm.transhipment,
        portofLoading: $scope.lcForm.PortofLoading,
        maximumCreditAmount : $scope.lcForm.MaxCreditAmount,

        //New Changes :Deepak :begin 24-03-2017

        draftsAtSight : $scope.lcForm.DraftsAt_sight,
        draftsAtUsance :  $scope.lcForm.DraftsAt_usance,
        shipmentPeriodSight : $scope.lcForm.shipmentperiod_sight,
        shipmentPeriodUsance : $scope.lcForm.shipmentperiod_usance,
        percentageSight : $scope.lcForm.Percentage_sight,
        percentageUsance :$scope.lcForm.Percentage_usance,
        lcAmountSight : $scope.lcForm.lcamount_sight,
        lcAmountUsance : $scope.lcForm.lcamount_usance,

        //New Changes :Deepak :End 24-03-2017

        partialShipments : $scope.lcForm.PartialShipments,
        senderToReceiverInformation : $scope.lcForm.SenderToReceiverInfo,
        charges : $scope.lcForm.Charges,
        confirmationInstructions : $scope.lcForm.ConfirmationInstruction,
        sequenceOfTotal : $scope.lcForm.SequenceTotal,
        ibanNumber : $scope.lcForm.iban,
        incoTerms:$scope.lcForm.incoTerms,
        status : "PENDING",

                                      };
//                                      console.log("value",$scope.lcForm.SequenceTotal);
//                                      console.log("key",sequenceOfTotal);
                                       console.log("loc  >",loc);

                                       const createLCEndpoint =
                                          apiBaseURL +
                                          "/lcreq";

										  console.log('createLCEndpoint',createLCEndpoint);
                                  $http.post(createLCEndpoint, loc).then(
                                     function(result){
                                      // success callback
                                      console.log("INSIDE SUCCESS FUNCTION");
									  shareidCustomer.tab=1;

                                      $location.path("/customerHome");
                                      displayMessage(result);
                                      }, 
                                      function(result){
                                      // failure callback
                                      console.log("INSIDE ERROR FUNCTION");
                                      displayMessage(result);
                                      }
                                      );
                                  }
                              };

                              displayMessage = (message) => {
                                  const modalInstanceTwo = $uibModal.open({
                                      templateUrl: 'messageContent.html',
                                      controller: 'messageCtrl',
                                      controllerAs: 'modalInstanceTwo',
                                      resolve: { message: () => message }
                                  });

                                  modalInstanceTwo.result.then(() => {}, () => {});
                              };
                            $scope.cancel = () => {
								shareidCustomer.tab=1;
								$location.path("/customerHome");
                                          }
                         function invalidFormInput() {
                                  const invalidNonItemFields = !$scope.lcForm.lcReqNo
                          //            || isNaN(modalInstance.form.orderNumber)
                          //            || !modalInstance.form.deliveryDate
                          //            || !modalInstance.form.city
                          //            || !modalInstance.form.country;
                          //
                          //        const inValidCounterparty = modalInstance.form.counterparty === undefined;
                          //
                          //        const invalidItemFields = modalInstance.items
                          //            .map(item => !item.name || !item.amount || isNaN(item.amount))
                          //            .reduce((prev, curr) => prev && curr);

                                  return invalidNonItemFields;
                              }
                              }
                              else{
                              $location.path("/customer");
                              }

                        });
app.controller('messageCtrl', function ($uibModalInstance, message) {
            const modalInstanceTwo = this;
            modalInstanceTwo.message = message.data;
            console.log("message inside messageCtrl  ",modalInstanceTwo.message);
        });








// //directive for tabbed request page starts//////////////////////////////////////
app.directive('tabHighlight', [function(){
    return {
      restrict: 'A',
      link: function(scope, element) {
        var x, y, initial_background = 'black';

        element
          .removeAttr('style')
          .mousemove(function (e) {
            // Add highlight effect on inactive tabs
            if(!element.hasClass('active'))
            {
              x = e.pageX - this.offsetLeft;
              y = e.pageY - this.offsetTop;

              element


            }
          })

      }
    };
  }]);
// //directive for tabbed request page ends////////////////////////////////////////
