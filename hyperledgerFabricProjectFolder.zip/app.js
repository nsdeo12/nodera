	var express = require('express');
	var path = require('path');
	var favicon = require('serve-favicon');
	var logger = require('morgan');
	var cookieParser = require('cookie-parser');
	var bodyParser = require('body-parser');
	var parseJson = require('parse-json');
	var routes = require('./routes/index');
	var users = require('./routes/users');
	var dishrouter = require('./routes/dishrouter');
	var promorouter = require('./routes/promorouter');
	var leaderrouter = require('./routes/leaderrouter');
	//var customerRouter=require('./routes/customerRouter');
	//var employeeRouter=require('./routes/employeeRouter');
var morgan         = require('morgan');        // log requests to the console (express4)
var bodyParser     = require('body-parser');     // pull information from HTML POST (express4)
  //  var methodOverride = require('method-override'); // simulate DELETE and PUT (express4)
    var fs = require('fs');
	
	var alfabank = express();

	var betabank = express();
	
	 var inf;
	 alfabank.use(morgan('dev')); 
	  alfabank.use(bodyParser.urlencoded({'extended':'true'}));            // parse application/x-www-form-urlencoded
    alfabank.use(bodyParser.json());                                     // parse application/json
    alfabank.use(bodyParser.json({ type: 'application/vnd.api+json' })); // parse application/vnd.api+json as json
	
	
	var Ibc1 = require('ibm-blockchain-js');                                                                                                                                                                                                                  //rest based SDK for ibm blockchain
var ibc = new Ibc1();



try{
                //this hard coded list is intentionaly left here, feel free to use it when initially starting out
                //please create your own network when you are up and running
                var manual = JSON.parse(fs.readFileSync('mycreds_docker_compose.json', 'utf8'));
                //var manual = JSON.parse(fs.readFileSync('mycreds.json', 'utf8'));
                //var manual = JSON.parse(fs.readFileSync('testcreds.json', 'utf8'));
                //var manual = JSON.parse(fs.readFileSync('mycreds_bluemix.json', 'utf8'));
                var peers = manual.credentials.peers;
                console.log('loading hardcoded peers',peers);
                var users = null;                                                                                                                                                                                                                                                                                                                //users are only found if security is on
                if(manual.credentials.users) users = manual.credentials.users;
                console.log('loading hardcoded users',users);
}
catch(e){
                console.log('Error - could not find hardcoded peers/users, this is okay if running in bluemix');
}
	 
	 


	// view engine setup
	alfabank.set('views', path.join(__dirname, 'views'));
	alfabank.set('view engine', 'jade');

	betabank.set('views', path.join(__dirname, 'views'));
	betabank.set('view engine', 'jade');

	// uncomment after placing your favicon in /public
	//alfabank.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));
	alfabank.use(logger('dev'));
	alfabank.use(bodyParser.json());
	alfabank.use(bodyParser.urlencoded({
	  extended: false
	}));
	alfabank.use(cookieParser());
	alfabank.use(express.static(path.join(__dirname, 'public')));

	betabank.use(logger('dev'));
	betabank.use(bodyParser.json());
	betabank.use(bodyParser.urlencoded({
	  extended: false
	}));
	betabank.use(cookieParser());
	betabank.use(express.static(path.join(__dirname, 'public')));




	//alfabank.use('/', routes);

	//alfabank.use('/users', users);
	//alfabank.use('/dishes',dishrouter);
	//alfabank.use('/leaders',leaderrouter);
	//alfabank.use('/promos',promorouter);

	//alfabank.use('/customer',customerRouter);
	//alfabank.use('/employee',employeeRouter);



	var mysql = require('mysql');
	var shareddb = mysql.createPool({
	  connectionLimit: 125,
	  host: 'localhost',
	  user: 'root',
	  password: 'root',
	  database: 'shareddb'
	});



	var beneficiarybank = mysql.createPool({
	  connectionLimit: 25,
	  host: 'localhost',
	  user: 'root',
	  password: 'root',
	  database: 'beneficiarybank'
	});



	var applicantbank = mysql.createPool({
	  connectionLimit: 125,
	  host: 'localhost',
	  user: 'root',
	  password: 'root',
	  database: 'applicantbank'
	});


	
	var chaincode  = null;
var ccdeployed = null;
var parseval = null;
	
	
	var options =      {
network:{
				peers: [
					  {
									"api_host": "localhost", //replace with your hostname or ip of a peer                                        //replace with your https port (optional, omit if n/a)
									"api_port": 7050,        //replace with your http port
									"type": "peer",
									"id": "jdoe"             //unique id of peer
					  }
				],                                                                                                                                                                                                                                                                             //lets only use the first peer! since we really don't need any more than 1
				users: [
					  {
									"enrollId": "bob",
									"enrollSecret": "NOE63pEQbL25"                        //enroll's secret
					  }
					],
					//dump the whole thing, sdk will parse for a good one
				options: {
					quiet: true,                                                                                                                                                                                                                                         //detailed debug messages on/off true/false
					tls: false,                                                                                                                                                                              //should app to peer communication use tls?
					maxRetry: 1                                                                                                                                                                                                                                                        //how many times should we retry register before giving up
						},                                                                                                                             
},
chaincode:{
				//zip_url: 'https://github.com/ibm-blockchain/marbles/archive/v2.0.zip',
				                                                                                                                                                                                                    //subdirectroy name of chaincode after unzipped
				//git_url: 'http://gopkg.in/ibm-blockchain/marbles.v2/chaincode',                                                                                         //GO get http url
	 
				 git_url:'https://github.com/bminchal/chain1/blob/master/git_code/',  
				zip_url: 'https://github.com/bminchal/chain1/archive/master.zip',
				//unzip_dir: 'marbles-2.0/chaincode',
				unzip_dir: '/chain1-master/git_code/', 
				
				 deployed_name: 'lc',
				
				//hashed cc name from prev deployment, comment me out to always deploy, uncomment me when its already deployed to skip deploying again
				//deployed_name: '16e655c0fce6a9882896d3d6d11f7dcd4f45027fd4764004440ff1e61340910a9d67685c4bb723272a497f3cf428e6cf6b009618612220e1471e03b6c0aa76cb'
}
};

// ---- Fire off SDK ---- //



//// Post method /////

// create todo and send back all todos after creation
                                                                                                                                                                                                                //sdk will populate this var in time, lets give it high scope by creating it here
ibc.load(options, function (err, cc ){                                                              //parse/load chaincode, response has chaincode functions!
                if(err != null){
                                console.log("options===>",options);
                                
                                console.log('! looks like an error loading the chaincode or network, app will fail\n', err);
                }
                else{
                                chaincode = cc;                                 
                                
                                

                                // ---- To Deploy or Not to Deploy ---- //
                                if(!cc.details.deployed_name || cc.details.deployed_name === ''){                                                                         //yes, go deploy
                                                cc.deploy('init', ['99'], {delay_ms: 30000}, function(e){                                                                                    //delay_ms is milliseconds to wait after deploy for conatiner to start, 50sec recommended
                                                                check_if_deployed(e, 1);
                                                });
                                }
                                else{                                                                                                                                                                                                                                                                                                                      //no, already deployed
                                                console.log('chaincode summary file indicates chaincode has been previously deployed');
                                                check_if_deployed(null, 1);
                                }
                }
});


//loop here, check if chaincode is up and running or not

function check_if_deployed(e, attempt){
                if(e){
                                cb_deployed(e);                                                                                                                                                                                                                                                                                              //looks like an error pass it along
                }
                
                cb_deployed(null);
                
                
}


function cb_deployed(e){
                if(e != null){
                                //look at tutorial_part1.md in the trouble shooting section for help
                                console.log('! looks like a deploy error, holding off on the starting the socket\n', e);        
                }              
                else{
                                console.log('------------------------------------------ Service Up ------------------------------------------');

                                ccdeployed = "deployed";
                                
                }
                
                
}
                         
alfabank.post('/lc-open', function(req, res) {                            
var loc = req.body;
console.log("TEXT FROM UqqqqqqqqqqI",loc);       
var ID = loc.lcId;
var LCID = loc.lcId;
var LCREQ = loc.lcReqId;

applicantbank.query("UPDATE letterofcredit SET status ='OPENED' WHERE lcreqid = ?", [LCREQ], function(err, result){
if(err) throw err;
console.log('updated record:', result);  
});

var input  = JSON.stringify(loc); 
chaincode.invoke.OpenLetterOfCredit([ID, input]);
var response = res.end(ID+" Created Successfully");
return response;

});
	
alfabank.get('/api/GetLcById/:id', function(req, res) {

idValue = req.params.id
chaincode.query.GetLcById([idValue], function(err, resp){                   

if(resp != null){                  
console.log("resp ===>",resp); 
var parseval = JSON.parse(resp);              
console.log("parseval ==>",parseval);                                                    
var info = {
"DATA": parseval
};                                          
res.json(info);                                 
}                                              
});                                           
});

alfabank.get('/lc-orders', function(getreqang, getresang) {
chaincode.query.GetAllLC([''], function(err, resp){                            
console.log("resp ===>",resp);
if(resp != null){                  
console.log("resp ===>",resp);
var sTemp = "";
var aObjs = [];

for(var i=0; i<resp.length; ++i)
{
sTemp += resp[i];
if (resp[i] == "}")
{
aObjs.push(JSON.parse(sTemp));
sTemp = "";					
}
}                          
getresang.json(aObjs);
}                                              
});                                         
});


betabank.get('/lc-orders', function(getreqang, getresang) {	     
chaincode.query.GetAllLC([''], function(err, resp){                            
console.log("resp ===>",resp);
if(resp != null){                  
console.log("resp ===>",resp);
var sTemp = "";
var aObjs = [];

for(var i=0; i<resp.length; ++i)
{
sTemp += resp[i];
if (resp[i] == "}")
{
aObjs.push(JSON.parse(sTemp));
sTemp = "";				
}
} 
console.log("aObjs", aObjs);                                       
getresang.json(aObjs);             
}                                              
});                                         
});



betabank.post('/lc-approve', function(getreqang, getresang) {
var input = getreqang.body;

console.log("input   ",input);
chaincode.invoke.UpdateStatus([input.lcId, input.status]);
var response = getresang.end(input.lcId+" updated Successfully");
return response;                                      
});

betabank.get('/', function(req, res) {
res.sendFile(path.join(__dirname + '/index.html'));
})
alfabank.get('/', function(req, res) {
res.sendFile(path.join(__dirname + '/index.html'));
});

alfabank.get('/test', function(req, res) {
});

alfabank.get('/me', function(req, res) {
res.send("ALFABank");
});

betabank.get('/me', function(req, res) {
res.send("BETABank");
});


alfabank.get('/lcRequestID', function(req, res) {

var hrTime = process.hrtime();
var temp = hrTime[0] * 1000000 + hrTime[1] / 1000;
//console.log(hrTime[0] * 1000000 + hrTime[1] / 1000)
res.send(Math.floor(temp).toString());

});

betabank.get('/lcRequestID', function(req, res) {

var hrTime = process.hrtime();
var temp = hrTime[0] * 1000000 + hrTime[1] / 1000;
//console.log(hrTime[0] * 1000000 + hrTime[1] / 1000)
res.send(Math.floor(temp).toString());

});	

alfabank.get('/customer/:email', function(req, res) {
var param = req.params.email;
//console.log("URL ",param);
//test(param);
var queryString = "SELECT name FROM CUSTOMER WHERE EMAIL=? AND bank='ALPHABank'";
console.log(queryString);

shareddb.getConnection(function(err, connection) {
connection.query(queryString, [param], function(err, rows, fields) {
if (err) {
res.send("FAILURE");
}
console.log("Login Customer ", rows);

if (rows.length <= 0) {
res.send(" [ { Result: 'Failure' } ]");
return;
} else {
res.send(rows);
return
}

connection.release();
});
});

});

betabank.get('/customer/:email', function(req, res) {
var param = req.params.email;
//console.log("URL ",param);
//test(param);
var queryString = "SELECT name FROM CUSTOMER WHERE EMAIL=? AND bank='BETABank'";
console.log(queryString);

shareddb.getConnection(function(err, connection) {
connection.query(queryString, [param], function(err, rows, fields) {
if (err) {
res.send("FAILURE");
}
console.log("Login Customer ", rows);

if (rows.length <= 0) {
res.send(" [ { Result: 'Failure' } ]");
return;
} else {
res.send(rows);
return
}

connection.release();
});
});

});

alfabank.get('/employee/:emailid', function(req, res) {
var param = req.params.emailid;
console.log("URL ROUT ", param);

console.log("URL ", alfa.address().port);

var queryString = 'SELECT name FROM EMPLOYEE WHERE EMAIL=?';
console.log(queryString);

applicantbank.getConnection(function(err, connection) {
connection.query(queryString, [param], function(err, rows, fields) {
if (err) {
res.send("FAILURE");
}
console.log("Login EMPLOYEE ", rows);

if (rows.length <= 0) {
res.send(" [ { Result: 'Failure' } ]");
return;
} else {
res.send(rows);
return
}

connection.release();
});

});
});


betabank.get('/employee/:emailid', function(req, res) {
var param = req.params.emailid;
console.log("URL ROUT ", param);

console.log("URL ", alfa.address().port);

var queryString = 'SELECT name FROM EMPLOYEE WHERE EMAIL=?';
console.log(queryString);

beneficiarybank.getConnection(function(err, connection) {
connection.query(queryString, [param], function(err, rows, fields) {
if (err) {
res.send("FAILURE");
}
console.log("Login EMPLOYEE ", rows);

if (rows.length <= 0) {
res.send(" [ { Result: 'Failure' } ]");
return;
} else {
res.send(rows);
return
}

connection.release();
});

});
});

alfabank.get('/customer/detail/id/:name', function(req, res) {
var param = req.params.name;
console.log("name ", param);
var queryString = 'SELECT * FROM CUSTOMER WHERE NAME=?';
console.log(queryString);
shareddb.getConnection(function(err, connection) {
connection.query(queryString, [param], function(err, rows, fields) {
if (err) {
res.send("FAILURE");
}
console.log("Login EMPLOYEE ", rows);

if (rows.length <= 0) {
res.send(" [ { Result: 'Failure' } ]");
return;
} else {
res.send(rows);
return
}

connection.release();
});

});

});

alfabank.get('/othercustomer', function(req, res) {
var queryString ='SELECT * FROM CUSTOMER WHERE bank !=?';
console.log(queryString);
var bank='ALPHABank';
shareddb.getConnection(function(err, connection) {
connection.query(queryString, [bank], function(err, rows, fields) {
if (err) {
res.send("FAILURE");
}
console.log("Login EMPLOYEE ", rows);

if (rows.length <= 0) {
res.send(" [ { Result: 'Failure' } ]");
return;
} else {
res.send(rows);
return
}

connection.release();
});
});
});

betabank.get('/othercustomer', function(req, res) {
var queryString ='SELECT * FROM CUSTOMER WHERE bank !=?';
console.log(queryString);
var bank='BETABank';
shareddb.getConnection(function(err, connection) {
connection.query(queryString, [bank], function(err, rows, fields) {
if (err) {
res.send("FAILURE");
}
console.log("Login EMPLOYEE ", rows);
if (rows.length <= 0) {
res.send(" [ { Result: 'Failure' } ]");
return;
} else {
res.send(rows);
return
}
connection.release();
});
});
});

alfabank.get('/customer/detail/:ibanValue', function(req, res) {
var param = req.params.ibanValue;
var queryString ='SELECT * FROM CUSTOMER WHERE IBANNO=?';
console.log(queryString);
shareddb.getConnection(function(err, connection) {
connection.query(queryString, [param], function(err, rows, fields) {
if (err) {
res.send("FAILURE");
}
console.log("Login EMPLOYEE ", rows);
if (rows.length <= 0) {
res.send(" [ { Result: 'Failure' } ]");
return;
} else {
res.send(rows);
return
}
connection.release();
});
});
});

betabank.get('/employee-lc-orders/:LCApprovalId', function(req, res) {
idValue = req.params.LCApprovalId
console.log("idValue",idValue);
chaincode.query.GetLcById([idValue], function(err, resp){                
if(resp != null){                  
console.log("resp ===>",resp); 
var parseval = JSON.parse(resp);              
console.log("parseval ==>",parseval);                                                    
var info = {
"DATA": parseval
};                                          
res.json(info);
}                                              
});    
});

alfabank.post('/lcreq', function(postreqang, postresang) {
var inf = postreqang.body;
console.log("TEXT FROM UI",inf);
var uidata = inf;
console.log("chaincode in uidata===>",uidata);
var record= [{
"lcReqId" : uidata.lcReqId,
"applicantCustomer" : uidata.applicantCustomer,
"applicantAddress" : uidata.applicantAddress,
"lcExpiryDate" : uidata.lcExpiryDate ,
"modeOfShipment" :uidata.modeOfShipment,
"beneficiaryId" : uidata.beneficiaryId,
"beneficiaryAddress" : uidata.beneficiaryAddress,
"lcType" : uidata.lcType,
"lcCurrency" : uidata.lcCurrency,
"lcAmount" : uidata.lcAmount,
"lcIssueDate" :  uidata.lcIssueDate,
"lcExpiryPlace" : uidata.lcExpiryPlace,
"latestShipmentDate" : uidata.latestShipmentDate,
"liabilityReversalDate" : uidata.liabilityReversalDate,
"advisingBankID" : uidata.advisingBankID,
"applicantBank" : uidata.applicantBank,
"applicantBankAddress" : uidata.applicantBankAddress,
"advisingBankAddress" : uidata.advisingBankAddress,
"formofDocumentaryCredit" : uidata.formofDocumentaryCredit,
"documentaryCreditNumber" : uidata.documentaryCreditNumber,
"availableWithBy" : uidata.availableWithBy,
"forTransportationTo" : uidata.forTransportationTo,
"descriptionOfGoodsAndOrServices" : uidata.descriptionOfGoodsAndOrServices,
"additionalConditions" : uidata.additionalConditions,
"periodForPresentation" : uidata.periodForPresentation,
"advisingThroughBank" : uidata.advisingThroughBank,
"transshipment" : uidata.transshipment,
"portofLoading": uidata.portofLoading,
"maximumCreditAmount" : uidata.maximumCreditAmount,
"draftsAtSight" : uidata.draftsAtSight,
"draftsAtUsance" :  uidata.draftsAtUsance,
"shipmentPeriodSight" : uidata.shipmentPeriodSight,
"shipmentPeriodUsance" : uidata.shipmentPeriodUsance,
"percentageSight" : uidata.percentageSight,
"percentageUsance" :uidata.percentageUsance,
"lcAmountSight" : uidata.lcAmountSight,
"lcAmountUsance" : uidata.lcAmountUsance,
"partialShipments" : uidata.partialShipments,
"senderToReceiverInformation" : uidata.senderToReceiverInformation,
"charges" : uidata.charges,
"confirmationInstructions" : uidata.confirmationInstructions,
"sequenceOfTotal" : uidata.sequenceOfTotal,
"ibanNumber" : uidata.ibanNumber,
"incoTerms":uidata.incoTerms,
"status" : "requested",
}];

applicantbank.query('INSERT INTO letterofcredit SET ?', record, function(err,res){
if(err) throw err;

console.log('Last record insert id:', res.lcid);
var response = postresang.end("LC Request No "+uidata.lcReqId+" has been successfully processed.");
return response;
});
});

alfabank.get('/lcreq',function (req, res) {
var queryString = "SELECT * FROM letterofcredit where status='requested' ";
console.log(queryString);
applicantbank.getConnection(function(err, connection) {
connection.query(queryString, function(err, rows, fields) {
if (err){
res.send("FAILURE");
}
console.log("Login Customer ",rows);
if(rows.length <=0){
res.send(" [ { Result: 'Failure' } ]");
return;
}
else{
res.send(rows);
return
}
connection.release();
});
});
});


betabank.get('/lcreq',function (req, res) {
var queryString = "SELECT * FROM letterofcredit where status='requested' ";
console.log(queryString);

beneficiarybank.getConnection(function(err, connection) {
connection.query(queryString, function(err, rows, fields) {
if (err){
res.send("FAILURE");
}
console.log("Login Customer ",rows);
if(rows.length <=0){
res.send(" [ { Result: 'Failure' } ]");
return;
}
else{
res.send(rows);
return
}
connection.release();
});
});
});	

//for individual req
alfabank.get('/lcreq/:LCReqNumb', function(req, res) {
var param = req.params.LCReqNumb;
var queryString ='select * from letterofcredit where lcreqid=?';
console.log(queryString);
applicantbank.getConnection(function(err, connection) {
connection.query(queryString, [param], function(err, rows, fields) {
if (err) {
res.send("FAILURE");
}
console.log("requested LC ", rows);
if (rows.length <= 0) {
res.send(" [ { Result: 'Failure' } ]");
return;
} else {
res.send(rows);
return
}
connection.release();
});
});
});

alfabank.get('/get-customer-lc/:name', function (req, res) {
var param=req.params.name;
var queryString = "select * from letterofcredit where status='requested' and applicantcustomer=?";
console.log(queryString);
applicantbank.getConnection(function(err, connection) {
connection.query(queryString,[param], function(err, rows, fields) {
if (err){
res.send("FAILURE");
}
if(rows.length <=0){
res.send(" [ { Result: 'Failure' } ]");
return;
}
else{
res.send(rows);
return
}
connection.release();
});
});
});

var alfa = alfabank.listen(10005, function() {
});

var host = alfa.address().address
var port1 = alfa.address().port

console.log("ALFA BANK listening at http://%s:%s", host, port1)


var beta = betabank.listen(10007, function() {
});

var host = beta.address().address
var port2 = beta.address().port

console.log("BETA BANK listening at http://%s:%s", host, port2)

exports.port = port1
//module.exports = alfa;
